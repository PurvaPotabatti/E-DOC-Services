<?php
//Include the function file
require_once('lib/functions.php');
$db = new class_functions();

if (isset($_POST['submit'])) {
    $var_service_name = $_POST['service_name'];
    $var_name_applicant = $_POST['name_applicant'];
    $var_name_father = $_POST['name_father'];
    $var_name_mother = $_POST['name_mother'];
    $var_dob = $_POST['dob'];
    $var_gender = $_POST['gender'];
    $var_age = $_POST['age'];
    $var_house_no = $_POST['house_no'];
    $var_district = $_POST['district'];
    $var_state = $_POST['state'];
    $var_poi = $_POST['poi'];
    $var_poi_file = "-";
    $var_poa = $_POST['poa'];
    $var_poa_file = "-";
    $var_pob = $_POST['pob'];
    $var_pob_file = "-";
    $var_por = $_POST['por'];
    $var_por_file = "-";
    $var_photo_applicant = "-";
    $var_sign_applicant = "-";




    $valid_formats = array("jpg", "png", "gif", "bmp", "jpeg", "JPEG", "JPG", "BMP", "PNG", "GIF");


    if (isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST") {


        //poi


        $name = $_FILES['poi_file']['name'];
        $size = $_FILES['poi_file']['size'];
        $var_poi_file = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['poi_file']['tmp_name'];

                $img_Dir = "poi_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {
                    // $db->insert_file($var_poi_file);
                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }



        ///poa  



        $name = $_FILES['poa_file']['name'];
        $size = $_FILES['poa_file']['size'];
        $var_poa_file = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['poa_file']['tmp_name'];

                $img_Dir = "poa_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {

                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }



        //pob

        $name = $_FILES['pob_file']['name'];
        $size = $_FILES['pob_file']['size'];
        $var_pob_file = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['pob_file']['tmp_name'];

                $img_Dir = "pob_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {

                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }



        //por


        $name = $_FILES['por_file']['name'];
        $size = $_FILES['por_file']['size'];
        $var_por_file = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['por_file']['tmp_name'];

                $img_Dir = "por_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {
                    // $db->insert_file($var_poi_file);
                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }



        //caste_certificate 

                //photo


        $name = $_FILES['photo_applicant']['name'];
        $size = $_FILES['photo_applicant']['size'];
        $var_photo_applicant = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['photo_applicant']['tmp_name'];

                $img_Dir = "photo_applicant_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {
                    // $db->insert_file($var_poi_file);
                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }



        //sign


        $name = $_FILES['sign_applicant']['name'];
        $size = $_FILES['sign_applicant']['size'];
        $var_sign_applicant = $name;

        if (strlen($name)) {
            list($txt, $ext) = explode(".", $name);

            if (in_array($ext, $valid_formats)) {
                $tmp = $_FILES['sign_applicant']['tmp_name'];

                $img_Dir = "sign_applicant_files/";

                if (!file_exists($img_Dir)) {
                    mkdir($img_Dir);
                }

                if (move_uploaded_file($tmp, $img_Dir . $name)) {
                    // $db->insert_file($var_poi_file);
                } else {
                    $image_error = "failed";
                    $flag = 1;
                }
            } else {
                $image_error = "Invalid file format";
                $flag = 1;
            }
        }


    }

    $db->my_user(
        $var_service_name,
        $var_name_applicant,
        $var_name_father,
        $var_name_mother,
        $var_dob,
        $var_gender,
        $var_age,
        $var_house_no,
        $var_district,
        $var_state,
        $var_poi,
        $var_poi_file,
        $var_poa,
        $var_poa_file,
        $var_pob,
        $var_pob_file,
        $var_por,
        $var_por_file,
        $var_photo_applicant,
        $var_sign_applicant
    );
 //require_once('payment_demo.php');

}

?>

<html>

<head>
    <title>services_page</title>
    <meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>

    <link rel="stylesheet" type="text/css" href="css/register_style.css" />
    <style>
        body {
            background-image: url("images/background8.jpg");
            width: 100%;
            height: 1000px;

        }
        .alert,
.success
{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
.next{
    float: right;
}
    </style>
</head>

<body>
    <?php
    require_once('header.php');
    ?>
     <div id="button" class="next">
        <button type="button" id="enable"name="submit_btn" class="btn btn-primary btn-lg btn-block" value="Submit" onclick="window.location.href='payment_demo.php';" style="width:100px; height:50px; text-align:center;">Next</button>
    
    </div>
    <div class="ctsm_container">
        <div class="form_design">
            <div class="header">
                <img src="images/aadhar_img.jpeg" alt="services_img" width="100%" height="300px">
                <br>
                <center>
                    <h1 style="color:white">Services</h1>
                </center>

            </div>

            <br>
            <br>
            <br>
            <br>

            <form action="servi.php" method="POST" enctype="multipart/form-data">
                <br>
                <br>


                <label class="lab">Choose Service :</label>
                <select class="inputbox" name="service_name" required>
                    <option value="select_service">Select Service</option>
                    <option value="aadhar_card">Aadhaar Card</option>
                    <option value="income_certificate">Income Certificate</option>
                    <option value="domicile_certificate">Domicile Certificate</option>
                    <option value="passport">Passport</option>
                    <option value="caste_certificate">Caste Certificate</option>
                    <option value="caste_validity">Caste Validity</option>
                    <option value="pan_card">Pan Card</option>
                    <option value="voter_id">Voter ID</option>
                    <option value="non_creamy_layer">Non-Creamy Layer</option>
                </select>
                <br>
                <br>


                <label class="lab">Name of Applicant:</label>
                <input class="inputbox" type="text" name="name_applicant" placeholder="Enter Name" required/>
                <br>
                <br>

                <label class="lab">Name of Father:</label>
                <input class="inputbox" type="text" name="name_father" placeholder="Enter Father Name" required/>
                <br>
                <br>

                <label class="lab">Name of Mother:</label>
                <input class="inputbox" type="text" name="name_mother" placeholder="Enter Mother Name" required/>
                <br>
                <br>

                <label class="lab">DOB:</label>
                <input class="inputbox" type="date" name="dob" placeholder="Enter Dob" required/>
                <br>
                <br>

                <label class="lab">Select gender:</label>
                <input type="radio" name="gender" checked value="male" /><label style="font-size:20px">Male</label>
                <input type="radio" name="gender" value="female" /><label style="font-size:20px">Female</label>
                <br>
                <br>

                <label class="lab">Age:</label>
                <input class="inputbox" type="number" name="age" placeholder="Enter Age" required/>
                <br>
                <br>

                <h2 style="font-size:30px; color:white">Address:</h2>
                <label class="lab">Enter House Address:</label>
                <textarea class="inputbox" name="house_no" placeholder="Enter Address" required >
</textarea>
                <br>
                <br>


                <label class="lab">District:</label>
                <input class="inputbox" type="text" name="district" placeholder="Enter District" required/>
                <br>
                <br>

                <label class="lab">State:</label>
                <input class="inputbox" type="text" name="state" placeholder="Enter State" required/>
                <br>
                <br>

                 
                <label style="color:white">NOTE - If you dont have your own below listed files then upload your parent's / guardian's.</label> 
                <label class="lab">Proof of Identity:</label>
                <select class="inputbox" name="poi" required>
                    <option value="select_poi">Select Proof of Identity</option>
                    <option value="pan_card">Pan Card</option>
                    <option value="ration_card">Ration Card</option>
                    <option value="voter_id">Voter ID</option>
                    <option value="driving_licence">Driving Licence</option>
                    <option value="atm_card">Bank ATM Card</option>
                </select>
                <input class="inputbox" type="file" name="poi_file" required>
                <br>
                <br>

                <label class="lab">Proof of Address:</label>
                <select class="inputbox" name="poa" required>
                    <option value="select_poa">Select Proof of Address</option>
                    <option value="passport">Passport</option>
                    <option value="passbook">Passbook</option>
                    <option value="voter_id">Voter ID</option>
                    <option value="driving_licence">Driving Licence</option>
                    <option value="electricity_bill">Electricity Bill</option>
                </select>
                <input class="inputbox" type="file" name="poa_file" required>
                <br>
                <br>

                <label class="lab">Proof of Birth:</label>
                <select class="inputbox" name="pob" required>
                    <option value="select_pob">Select Proof of Birth</option>
                    <option value="pan_card">Pan Card</option>
                    <option value="birth_certificate">Birth Certificate</option>
                    <option value="passport">Passport</option>
                    <option value="slc">School Leaving Certificate </option>
                </select>
                <input class="inputbox" type="file" name="pob_file" required>
                <br>
                <br>

                <label class="lab">Proof of Relationship:</label>
                <select class="inputbox" name="por" required>
                    <option value="Select_por">Select Proof of Relationship</option>
                    <option value="pds_card">PDS Card</option>
                    <option value="pension_card">Pansion Card</option>
                    <option value="passport">Passport</option>
                    <option value="marriage_certificate">Marriage Certificate</option>
                    <option value="atm_card">Bank ATM Card</option>
                </select>
                <input class="inputbox" type="file" name="por_file" required>
                <br>
                <br>

                <hr>


                



                <label class="lab">Photo of Applicant:</label>
                <input class="inputbox" type="file" name="photo_applicant" required/>
                <br>
                <br>

                <label class="lab">Signature of Applicant:</label>
                <input class="inputbox" type="file" name="sign_applicant" required/>
                <br>
                <br>


                <!--<center><button type="button" name="submit" class="btn btn-primary btn-lg btn-block submit_btn" value="Submit" onclick="window.location.href='payment_demo.php';" style="width:100px; height:50px; text-align:center;">Submit</button>
</center>-->
<center><a href="payment_demo.php"><input type="submit" name="submit" onclick="enablebtn()" class="btn btn-primary btn-lg btn-block submit_btn" value="Submit" style="width:100px; height:50px; text-align:center;"/></a>
</center>

                <?php
    if(isset($_POST['submit']))
    {
        echo "<div class='success'>Your Have Successfully Uploaded All The Details...!!!</div>";
		echo '<script type="text/javascript">enablebtn();</script>';
        enablebtn();
    }
    ?>
    


            </form>
        </div>
<script type="text/javascript">
    function enablebtn(){
        document.getElementById("mybtn").disabled=false;
    }
</script>
</body>


</html>