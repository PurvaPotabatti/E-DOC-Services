<?php
	//Include function file
	require_once('lib/functions.php');
	$db = new class_functions();
	
	if(isset($_GET['logout']))
	{
		unset($_SESSION['login_mob_no']);
	}
	
	
	if(isset($_POST['submit_btn']))
	{
		$var_mobile_number = $_POST['mobile_number'];
		$var_password	=	$_POST['password'];
		
		$db_password	=	$db->get_user_password($var_mobile_number);
		
		if($db_password=="")
		{
			echo "This user is not registered with us. Check Mobile Number";
		}
		else
		{
			if($var_password==$db_password)
			{
				//echo "login Success";
				$_SESSION['login_mob_no']	=	$var_mobile_number;
				
				header("location:dashboard.php");
			}
			else{
				echo "Incorrect password";
			}
		}
		
	}
?>	
<html>
<head>
	<title>DT Bootstrap</title>
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-utilities.css" />
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
	
</head>
<body>

<?php
	require_once('header.php');
?>


<div class="container cstm_container">
  <div class="row">
    <div class="col col-md-3 col-sm-3">
     
    </div>
    <div class="col col-md-6 cstm_form_container">
      
	  <h1 style="text-align:center;">Login To Account</h1>
	  
	  <div class="alert alert-success" role="alert">
		  Your account created successully
		</div>
	
		<form action="login.php" method="POST">
	
		<label class="label_val">Enter Mobile Number :</label>
	<input type="number" class="form-control" name="mobile_number"  placeholder="Enter Mobile Number" required />

	<br />
	
	
	<label class="label_val">Enter Password</label>
	<input type="password" required class="form-control" name="password" placeholder="Enter password" />
	
	  
	  <center><input type="submit" class="btn btn-warning" name="submit_btn" value="SUBMIT"></center>
	  
	  </form>
	  
    </div>
   <div class="col col-md-3">
      
	</div>
  </div>
</div>


</body>
</html>