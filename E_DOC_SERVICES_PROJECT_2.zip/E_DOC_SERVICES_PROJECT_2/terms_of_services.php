<html>
<head>
<title>Terms of sevices </title>
<meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="css/terms_style.css"  type="text/css">
</head>
<style>


.cstm_container
{
	background-image:url("images/back.jpg");
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: cambria;
}

body{
  font-size: 16px;
  
}

.flex_align_justify{
  display: flex;
  align-items: center;
  justify-content: center;
}

.flex_align{
  display: flex;
  align-items: center;
}

.wrapper{
  min-height: 100vh;
  padding: 0 20px;
}

.terms_service{
  width: 800px;
  max-width: 100%;
  height: 620px;
  background: #000033;
  border-radius: 3px;
  box-shadow: 0px 0px 3px rgba(0,0,0,0.15);
}

.terms_service .tc_item{
  padding: 20px 40px;
}

.terms_service .tc_head{
  box-shadow: 0 1px 2px rgba(0,0,0,0.15);
  height: 90px;
  color:white !important;
}

.terms_service .tc_head{
  
  color:#FFFFFF;
  margin-right: 20px;
  border-radius: 5%;
  font-size: 18px;
 
}

.terms_service .tc_body{
  height: calc(100% - 170px);
  overflow: auto;
  padding-right: 20px;
  color:#ccccff !important;
}

.terms_service .tc_body ol li{
  margin-bottom: 15px;
}

.terms_service .tc_body ol li h3{
  margin-bottom: 5px;
  color:#b3fff0;
}

.terms_service .tc_foot{
  box-shadow: 0 -1px 2px rgba(0,0,0,0.15);
  justify-content: space-between;
  height: 80px;
}

.terms_service .tc_foot button{
  width: 100%;
  border: 1px solid white;
  padding: 10px 20px;
  border-radius: 3px;
  cursor: pointer;
  transition: all 0.5s ease;
}

.terms_service .tc_foot button.decline_btn{
  margin-right: 20px;
  background:white;
  color:#000080;
}

.terms_service .tc_foot button.accept_btn{
  background: white;
  color: #000080;
}

.terms_service .tc_foot button.decline_btn:hover{
  background:#b3fff0;
  color:#000080;
  font-weight:bold;
}

.terms_service .tc_foot button.accept_btn:hover{
  background:#b3fff0;
  color:#000080;
   font-weight:bold;
}
</style>
<body>
<?php
     require_once('header.php');
?>
<div class="cstm_container">
<div class="wrapper flex_align_justify" >
  <div class="terms_service" style="padding-top:30px">
      <div class="tc_item tc_head flex_align_justify">
        
        <div class="text">
          <h2 style="color:white">TERMS OF SERVICES</h2>
          <p>Last updated on 07 July 2023</p>
        </div>
      </div>
      <div class="tc_item tc_body">
        <ol>
          <li>
            <h3>Terms of use</h3>
            <p>We will provide their services to you, which are subject to the conditions stated below in this document. Every time you visit this website, use its services or make a purchase, you accept the following conditions. This is why we urge you to read them carefully.</p>
          <li>
            <h3>Privacy Policy</h3>
            <p>Before you continue using our website we advise you to read our privacy policy [link to privacy policy] regarding our user data collection. It will help you better understand our practices.</p>
          </li>
          <li>
            <h3>Copyright</h3>
            <p>Content published on this website (digital downloads, images, texts, graphics, logos) is the property of [name] and/or its content creators and protected by international copyright laws. The entire compilation of the content found on this website is the exclusive property of Edoc services, with copyright authorship for this compilation by Edoc services ..</p>
          </li>
          <li>
            <h3>Communications</h3>
            <p>The entire communication with us is electronic. Every time you send us an email or visit our website, you are going to be communicating with us. You hereby consent to receive communications from us. If you subscribe to the news on our website, you are going to receive regular emails from us. We will continue to communicate with you by posting news and notices on our website and by sending you emails. You also agree that all notices, disclosures, agreements, and other communications we provide to you electronically meet the legal requirements that such communications be in writing.</p>
          </li>
          <li>
            <h3>License and Site Access</h3>
            <p>We grant you a limited license to access and make personal use of this website. You are not allowed to download or modify it. This may be done only with written consent from us.</p>
          </li>
		   <li>
            <h3>Comments, Reviews, and Emails</h3>
            <p>Visitors may post content as long as it is not obscene, illegal, defamatory, threatening, infringing of intellectual property rights, invasive of privacy, or injurious in any other way to third parties. Content has to be free of software viruses, political campaigns, and commercial solicitation.
            We reserve all rights (but not the obligation) to remove and/or edit such content. </p>
          </li>
		   <li>
            <h3>User Account</h3>
            <p>If you are an owner of an account on this website, you are solely responsible for maintaining the confidentiality of your private user details (username and password). You are responsible for all activities that occur under your account or password.</p>
          </li>
        </ol>
      </div>
      
  </div>
</div>
</body>
</html>