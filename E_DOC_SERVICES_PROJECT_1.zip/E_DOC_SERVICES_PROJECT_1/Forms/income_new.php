<html>
<head>
<title>Income certificate</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/stamp.jpg" width="100%" height="300px">
	<center><h1>Income certificate</h1></center>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<form action="registration_form.html"method="POST">

<br>
<br>


<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>

<label class="lab">Mobile Number:</label>
<input class="inputbox" type="number" name="mobile number" placeholder="Enter Mobile Number" />
<br>
<br>

<h3 class="lab">Address:</h3>
<label class="lab">Enter House Address:</label>
<textarea class="inputbox" name="house no" placeholder="Enter Address">
</textarea>
<br>
<br>

<label class="lab">City:</label>
<input class="inputbox" type="text" name="city" placeholder="Enter City" />
<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" />
<br>
<br>

<label class="lab">Enter Aadhar number of Applicant:</label>
<input class="inputbox" type="number" name="aadhar_no_applicant" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" /><label style="font-size:20px">Male</label>
<input type="radio" name="gender" value="female"/><label style="font-size:20px">Female</label>
<br>
<br>
<br>

<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi">
<option value="select_poi">Select Proof of Identity</option>
<option value="pan_card">Pan Card</option>
<option value="ration_card">Ration Card</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">
<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa">
<option value="select_poa">Select Proof of Address</option>
<option value="passport">Passport</option>
<option value="passbook">Passbook</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="electricity_bill">Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">
<br>
<br>


<label class="lab">Ration-card</label>
<br />
<input class="inputbox" type="file" name="Ration Card" />
<br>
<br>

<label class="lab"> Enter Father  Name:</label>
<input  class="inputbox" type="text" name="Name" placeholder="Enter Name" />
<br>
<br>

<label class="lab"> Enter Father Aadhar Number:</label>
<input  class="inputbox" type="text" name="aadhar_no" placeholder="Enter Aadhar Number" />
<br />
<br />

<label class="lab">Father Yearly-Income</label>
<select class="inputbox" name="pob">
<option value="10,000-50,000">10,000-50,000</option>
<option value="50,000-1,00000">50,000-1,00000</option>
<option value="1,00000-1,5000">1,00000-1,5000</option>
<option value="Above 1,5000">Above 1,5000</option>
</select>
<input class="inputbox" type="file" name="pob_file">
<br>
<br>

<label class="lab"> Father Salary-Slip</label>
<input class="inputbox" type="file" name="Slip"  />
<br>
<br>

<label class="lab">Photo of Applicant</label>
<input class="inputbox" type="file" name="photo_applicant"  />
<br>
<br>

<label class="lab">Signature of Applicant</label>
<input class="inputbox" type="file" name="sign_applicant"  />
<br>
<br>
<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end">
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right">

</form>
</body>
</html> 