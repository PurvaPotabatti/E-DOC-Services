 <html>
<head>
<title>Aadhar card</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/aadhar_img.jpeg" width="100%" height="300px">
	<center><h1>Aadhar Card</h1></center>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<form action="aadhar_card_registration.html" method="POST">
<br>
<br>

<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>

<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" /><label style="font-size:20px">Male</label>
<input type="radio" name="gender" value="female"/><label style="font-size:20px">Female</label>
<br>
<br>

<label class="lab">Age:</label>
<input class="inputbox" type="number" name="age" placeholder="Enter Age" />
<br>
<br>

<h2 style="font-size:30px">Address:</h2>
<label class="lab">Enter House Address:</label>
<textarea class="inputbox" name="house_no" placeholder="Enter Address">
</textarea>
<br>
<br>

<label class="lab">City:</label>
<input class="inputbox" type="text" name="city" placeholder="Enter City" />
<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" />
<br>
<br>

<label class="lab">Pin Code:</label>
<input class="inputbox" type="number" name="pin_code" placeholder="Enter Pin Code" />
<br>
<br>

<label class="lab">Enter Aadhar number of Applicant:</label>
<input class="inputbox" type="number" name="aadhar_no_applicant" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi">
<option value="select_poi">Select Proof of Identity</option>
<option value="pan_card">Pan Card</option>
<option value="ration_card">Ration Card</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">
<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa">
<option value="select_poa">Select Proof of Address</option>
<option value="passport">Passport</option>
<option value="passbook">Passbook</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="electricity_bill">Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">
<br>
<br>

<label class="lab">Proof of Birth:</label>
<select class="inputbox" name="pob">
<option value="select_pob">Select Proof of Birth</option>
<option value="pan_card">Pan Card</option>
<option value="birth_certificate">Birth Certificate</option>
<option value="passport">Passport</option>
<option value="slc">School Leaving Certificate </option>
</select>
<input class="inputbox" type="file" name="pob_file">
<br>
<br>

<label class="lab">Proof of Relationship:</label>
<select class="inputbox" name="por">
<option value="Select_por">Select Proof of Relationship</option>
<option value="pds_card">PDS Card</option>
<option value="pension_card">Pansion Card</option>
<option value="passport">Passport</option>
<option value="marriage_certificate">Marriage Certificate</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="por_file">
<br>
<br>

<h2 style="font-size:30px">Details of:</h2>
<p style="font-size:20px">[Note:Select any one]<p>
<input type="checkbox" name="father" value="father" /><label style="font-size:20px">Father</label>
<input type="checkbox" name="mother" value="mother" /><label style="font-size:20px">Mother</label>
<input type="checkbox" name="guardian" value="guardian" /><label style="font-size:20px">Guardian</label>
<input type="checkbox" name="husband" value="husband" /><label style="font-size:20px">Husband</label>
<input type="checkbox" name="wife" value="wife" /><labelstyle="font-size:20px">Wife</label>
<br>
<br>

<label class="lab"> Enter Name:</label>
<input  class="inputbox" type="text" name="Name" placeholder="Enter Name" />
<br>
<br>

<label class="lab">Aadhar Number:</label>
<input  class="inputbox" type="text" name="aadhar_no" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">Applicant Leaving Certificate</label>
<input class="inputbox" type="file" name="Leaving Certificate"  />
<br>
<br>

<label class="lab">Applicant Caste Certificate</label>
<input class="inputbox" type="file" name="Caste Certificate"  />
<br>
<br>

<label class="lab">Ration-card</label>
<br />
<input class="inputbox" type="file" name="Ration Card" />
<br>
<br>


<label  class="lab">Applicant Bonafide Certificate</label>
<br />
<label>(Note:Bonafide Should Be Of Current Year)</label>
<input class="inputbox" type="file" name="BonafideCertificate"  />
<br>
<br>

<label class="lab">Form 15A</label>
<br />
<label>(Note:College Stamp And Principal Signature)</label>
<input class="inputbox" type="file" name="Form"  />
<br>
<br>


<label class="lab"> Leaving Certificate</label>
<br >
<label>(Note:In Absence of Father Leaving Certificate Use Uncle Leaving Certificate)
<input class="inputbox" type="file" name="Leaving Certificate"  />
<br>
<br>

<label class="lab">10th Board Certificate:</label>
<input class="inputbox" type="file" name="10th_board_certificate"/>

<br>
<br>


<label class="lab"> Family Tree</label>
<input class="inputbox" type="file" name="family Tree"  />
<br>
<br>

<label class="lab">Form No.17</label>
<br />
<input class="inputbox" type="file" name="Form"  />
<br>
<br>

<label class="lab">Father Yearly-Income</label>
<select class="inputbox" name="pob">
<option value="10,000-50,000">10,000-50,000</option>
<option value="50,000-1,00000">50,000-1,00000</option>
<option value="1,00000-1,5000">1,00000-1,5000</option>
<option value="Above 1,5000">Above 1,5000</option>
</select>
<input class="inputbox" type="file" name="pob_file">
<br>
<br>

<label class="lab"> Father Salary-Slip</label>
<input class="inputbox" type="file" name="Slip"  />
<br>
<br>

<h2 style="font-size:30px">Details of:</h2>
<p style="font-size:20px">[Note:Select any one]<p>
<input type="checkbox" name="father" value="father" /><label style="font-size:20px">Father</label>
<input type="checkbox" name="mother" value="mother" /><label style="font-size:20px">Mother</label>
<input type="checkbox" name="guardian" value="guardian" /><label style="font-size:20px">Guardian</label>
<input type="checkbox" name="husband" value="husband" /><label style="font-size:20px">Husband</label>
<input type="checkbox" name="wife" value="wife" /><labelstyle="font-size:20px">Wife</label>
<br>
<br>

<label class="lab">Aadhar Card</label>
<input class="inputbox" type="file" name="aadhar_no"  />
<br>
<br>

<label class="lab">Voter ID</label>
<input class="inputbox" type="file" name="voter_id"  />
<br>
<br>

<label class="lab">Occupation:</label>
<input class="inputbox" type="text" name="occupation" placeholder="Enter your Occupation"  />
<br>
<br>


<label class="lab">Other documents</label>
<select class="inputbox" name="other_doc" required>
<option value="select_pob">Select Other document</option>
<option value="pan_card">Property tax receipt</option>
<option value="birth_certificate">Proof of caste of a relative</option>
<option value="passport">Caste certificate of applicant's father</option>
</select>
<input class="inputbox" type="file" name="other_doc_file" required>
<br>
<br>

<label class="lab">Affidavit for caste</label>
<input class="inputbox" type="file" name="caste" required>
<br>
<br>

<label class="lab">Photo of Applicant:</label>
<input class="inputbox" type="file" name="photo_applicant"  />
<br>
<br>

<label class="lab">Signature of Applicant:</label>
<input class="inputbox" type="file" name="sign_applicant"  />
<br>
<br>


<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end"/>
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right"/>


</form>
</div>

</body>
</html>