<?php
	require_once('lib/functions.php');
	$db = new class_functions();

	if(isset($_GET['edit_id']))
	{
		$edit_id	=	$_GET['edit_id'];
		$_SESSION['edit_id']	= $edit_id;
	}
	
	$edit_id	=	$_SESSION['edit_id'];
	
	if (isset($_POST['submit'])) {
        echo $var_service_name = $_POST['service_name'];
        $var_name_applicant = $_POST['name_applicant'];
        $var_name_father = $_POST['name_father'];
        $var_name_mother = $_POST['name_mother'];
        $var_dob = $_POST['dob'];
        $var_gender = $_POST['gender'];
        $var_age = $_POST['age'];
        $var_house_no = $_POST['house_no'];
        $var_district = $_POST['district'];
        $var_state = $_POST['state'];
        $var_poi = $_POST['poi'];
        $var_poi_file = "-";
        $var_poa = $_POST['poa'];
        $var_poa_file = "-";
        $var_pob = $_POST['pob'];
        $var_pob_file = "-";
        $var_por = $_POST['por'];
        $var_por_file = "-";
        $var_photo_applicant = "-";
        $var_sign_applicant = "-";
    
    
    
    
        $valid_formats = array("jpg", "png", "gif", "bmp", "jpeg", "JPEG", "JPG", "BMP", "PNG", "GIF");
    
    
        if (isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST") {
    
    
            //poi
    
    
            $name = $_FILES['poi_file']['name'];
            $size = $_FILES['poi_file']['size'];
            $var_poi_file = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['poi_file']['tmp_name'];
    
                    $img_Dir = "poi_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
                        // $db->insert_file($var_poi_file);
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
    
            ///poa  
    
    
    
            $name = $_FILES['poa_file']['name'];
            $size = $_FILES['poa_file']['size'];
            $var_poa_file = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['poa_file']['tmp_name'];
    
                    $img_Dir = "poa_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
    
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
    
            //pob
    
            $name = $_FILES['pob_file']['name'];
            $size = $_FILES['pob_file']['size'];
            $var_pob_file = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['pob_file']['tmp_name'];
    
                    $img_Dir = "pob_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
    
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
    
            //por
    
    
            $name = $_FILES['por_file']['name'];
            $size = $_FILES['por_file']['size'];
            $var_por_file = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['por_file']['tmp_name'];
    
                    $img_Dir = "por_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
                        // $db->insert_file($var_poi_file);
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
    
            
            //photo
    
    
            $name = $_FILES['photo_applicant']['name'];
            $size = $_FILES['photo_applicant']['size'];
            $var_photo_applicant = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['photo_applicant']['tmp_name'];
    
                    $img_Dir = "photo_applicant_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
                        // $db->insert_file($var_poi_file);
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
    
            //sign
    
    
            $name = $_FILES['sign_applicant']['name'];
            $size = $_FILES['sign_applicant']['size'];
            $var_sign_applicant = $name;
    
            if (strlen($name)) {
                list($txt, $ext) = explode(".", $name);
    
                if (in_array($ext, $valid_formats)) {
                    $tmp = $_FILES['sign_applicant']['tmp_name'];
    
                    $img_Dir = "sign_applicant_files/";
    
                    if (!file_exists($img_Dir)) {
                        mkdir($img_Dir);
                    }
    
                    if (move_uploaded_file($tmp, $img_Dir . $name)) {
                        // $db->insert_file($var_poi_file);
                    } else {
                        $image_error = "failed";
                        $flag = 1;
                    }
                } else {
                    $image_error = "Invalid file format";
                    $flag = 1;
                }
            }
    
    
        }
    
         $db->edit_service_record_new(  $var_service_name,
         $var_name_applicant,
         $var_name_father,
         $var_name_mother,
         $var_dob,
         $var_gender,
         $var_age,
         $var_house_no,
         $var_district,
         $var_state,
         $var_poi,
         $var_poi_file,
         $var_poa,
         $var_poa_file,
         $var_pob,
         $var_pob_file,
         $var_por,
         $var_por_file,
         $var_photo_applicant,
         $var_sign_applicant
         ,$res_edit_id);

    }

    $users_data = array();
    $users_data = $db-> service_update_new($edit_id);

    
    print_r($users_data);
    if (!empty($users_data))
    {
       
        $res_id			    =	$users_data['id'];
        $res_service_name   =   $users_data['res_service_name'];
        $res_name_applicant =   $users_data['res_name_applicant']; 
        $res_name_father    =   $users_data['res_name_father']; 
        $res_name_mother    =   $users_data['res_name_mother']; 
        $res_dob            =   $users_data['res_dob']; 
        $res_gender         =   $users_data['res_gender']; 
        $res_age            =   $users_data['res_age']; 
        $res_house_no       =   $users_data['res_house_no']; 
        $res_district       =   $users_data['res_district']; 
        $res_state          =   $users_data['res_state']; 
        $res_poi            =   $users_data['res_poi']; 
        $res_poi_file            =   $users_data['res_poi_file']; 
        $res_poa            =   $users_data['res_poa']; 
        $res_poa_file            =   $users_data['res_poa_file']; 
        $res_pob            =   $users_data['res_pob']; 
        $res_pob_file            =   $users_data['res_pob_file']; 
        $res_por            =   $users_data['res_por']; 
        $res_por_file            =   $users_data['res_por_file']; 
        $res_photo_applicant = $users_data['res_photo_applicant']; 
        $res_sign_applicant  = $users_data['res_sign_applicant']; 
        $res_date            = $users_data['res_date'];
        $res_time            = $users_data['res_time'];

       print_r($user_data);
    }
?>


<html>
<head>
<title>services_page</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/aadhar_img.jpeg" width="100%" height="300px">
	<center><h1>Services</h1></center>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<form action="edit_service.php" method="POST">
<br>
<br>


<label class="lab">Choose Service :</label>
<select class="inputbox" name="service_name">
<option value="select_service">Select Service</option>
<option value="aadhar_card" <?php if( $users_data['res_service_name'] == "aadhar_card"){ ?>selected <?php } ?> >Aadhaar Card</option>
<option value="income_certificate" <?php if( $users_data['res_service_name'] == "income_certificate"){ ?>selected <?php } ?> >Income Certificate</option>
<option value="domicile_certificate" <?php if( $users_data['res_service_name'] == "domicile_certificate"){ ?>selected <?php } ?> >Domicile Certificate</option>
<option value="passport" <?php if( $users_data['res_service_name'] == "passport"){ ?>selected <?php } ?> >Passport</option>
<option value="caste_certificate" <?php if( $users_data['res_service_name'] == "caste_certificate"){ ?>selected <?php } ?> >Caste Certificate</option>
<option value="caste_validity" <?php if( $users_data['res_service_name']== "caste_validity"){ ?>selected <?php } ?> >Caste Validity</option>
<option value="pan_card" <?php if( $users_data['res_service_name'] == "pan_card"){ ?>selected <?php } ?> >Pan Card</option>
<option value="voter_id" <?php if( $users_data['res_service_name'] == "voter_id"){ ?>selected <?php } ?> >Voter ID</option>
<option value="non_creamy_layer" <?php if( $users_data['res_service_name'] == "non_creamy_layer"){ ?>selected <?php } ?> >Non-Creamy Layer</option>
</select>
<br>
<br>


<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="name_applicant" placeholder="Enter Name" value="<?php echo  $users_data['res_name_applicant']; ?>"  />
<br>
<br>

<label class="lab">Name of Father:</label>
<input  class="inputbox" type="text" name="name_father" placeholder="Enter Father Name" value="<?php echo $users_data['$res_name_father'];?>" />
<br>
<br>

<label class="lab">Name of Mother:</label>
<input  class="inputbox" type="text" name="name_mother" placeholder="Enter Mother Name" value="<?php echo $users_data['$res_name_mother'];?>" />
<br>
<br>

<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" value="<?php echo $users_data['$res_dob'];?>" />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" value="male" <?php if($users_data['$res_gender'] == "male"){ ?> checked <?php } ?> /><label style="font-size:20px">Male</label>
<input type="radio" name="gender" value="female" <?php if($users_data['$res_gender'] == "female"){ ?> checked <?php } ?> /><label style="font-size:20px">Female</label>
<br>
<br>

<label class="lab">Age:</label>
<input class="inputbox" type="number" name="age" placeholder="Enter Age" value="<?php echo $users_data['$res_age'];?>" />
<br>
<br>

<h2 style="font-size:30px; color:white;">Address:</h2>
<label class="lab">Enter House Address:</label>
<textarea class="inputbox" name="house_no" placeholder="Enter Address" value="<?php echo $users_data['$res_house_no'];?>">
</textarea>
<br>
<br>


<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" value="<?php echo $users_data['$res_district'];?>" />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State"  value="<?php echo $users_data['$res_state'];?>"/>
<br>
<br>


<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi">
<option value="select_poi">Select Proof of Identity</option>
<option value="pan_card" <?php if($users_data['$res_poi'] == "pan_card"){ ?>selected <?php } ?> >Pan Card</option>
<option value="ration_card" <?php if($users_data['$res_poi'] == "ration_card"){ ?>selected <?php } ?> >Ration Card</option>
<option value="voter_id" <?php if($users_data['$res_poi'] == "voter_id"){ ?>selected <?php } ?>>Voter ID</option>
<option value="driving_licence" <?php if($users_data['$res_poi'] == "driving_licence"){ ?>selected <?php } ?> >Driving Licence</option>
<option value="atm_card" <?php if($users_data['$res_poi'] == "atm_card"){ ?>selected <?php } ?> >Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">
<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa">
<option value="select_poa">Select Proof of Address</option>
<option value="passport" <?php if($users_data['$res_poa'] == "passport"){ ?>selected <?php } ?>>Passport</option>
<option value="passbook" <?php if($users_data['$res_poa'] == "passbook"){ ?>selected <?php } ?>>Passbook</option>
<option value="voter_id" <?php if($users_data['$res_poa'] == "voter_id"){ ?>selected <?php } ?>>Voter ID</option>
<option value="driving_licence" <?php if($users_data['$res_poa'] == "driving_licence"){ ?>selected <?php } ?>>Driving Licence</option>
<option value="electricity_bill" <?php if($users_data['$res_poa'] == "electricity_bill"){ ?>selected <?php } ?>>Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">
<br>
<br>

<label class="lab">Proof of Birth:</label>
<select class="inputbox" name="pob">
<option value="select_pob">Select Proof of Birth</option>
<option value="pan_card" <?php if($users_data['$res_pob'] == "pan_card"){ ?>selected <?php } ?> >Pan Card</option>
<option value="birth_certificate" <?php if($users_data['$res_pob'] == "birth_certificate"){ ?>selected <?php } ?> >Birth Certificate</option>
<option value="passport" <?php if($users_data['$res_pob'] == "passport"){ ?>selected <?php } ?> >Passport</option>
<option value="slc" <?php if($users_data['$res_pob']  == "slc"){ ?>selected <?php } ?> >School Leaving Certificate </option>
</select>
<input class="inputbox" type="file" name="pob_file">
<br>
<br>

<label class="lab">Proof of Relationship:</label>
<select class="inputbox" name="por">
<option value="Select_por">Select Proof of Relationship</option>
<option value="pds_card" <?php if($users_data['$res_por'] == "pds_card"){ ?>selected <?php } ?> >PDS Card</option>
<option value="pension_card" <?php if($users_data['$res_por']  == "pension_card"){ ?>selected <?php } ?>>Pansion Card</option>
<option value="passport" <?php if($users_data['$res_por']  == "passport"){ ?>selected <?php } ?> >Passport</option>
<option value="marriage_certificate" <?php if($users_data['$res_por']  == "marriage_certificate"){ ?>selected <?php } ?>>Marriage Certificate</option>
<option value="atm_card" <?php if($users_data['$res_por']  == "atm_card"){ ?>selected <?php } ?> >Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="por_file" <?php //echo "$var_por_file"; ?>>
<br>
<br>

<hr>


<label class="lab">Photo of Applicant:</label>
<input class="inputbox" type="file" name="photo_applicant" value="<?php echo $users_data['$res_photo_applicant'];?>" />
<br>
<br>

<label class="lab">Signature of Applicant:</label>
<input class="inputbox" type="file" name="sign_applicant" value="<?php echo $users_data['$res_sign_applicant'];?>" />
<br>
<br>



<center><input type="submit" name="submit" value="Submit" class="submit_btn" style=""/></center>


</form>
</div>

</body>
</html>
