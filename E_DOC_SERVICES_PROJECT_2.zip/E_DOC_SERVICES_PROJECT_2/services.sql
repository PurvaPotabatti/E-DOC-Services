-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 17, 2023 at 04:50 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_doc_services`
--

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` text COLLATE utf8_unicode_ci NOT NULL,
  `name_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `name_father` text COLLATE utf8_unicode_ci NOT NULL,
  `name_mother` text COLLATE utf8_unicode_ci NOT NULL,
  `dob` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` text COLLATE utf8_unicode_ci NOT NULL,
  `age` text COLLATE utf8_unicode_ci NOT NULL,
  `house_no` text COLLATE utf8_unicode_ci NOT NULL,
  `district` text COLLATE utf8_unicode_ci NOT NULL,
  `state` text COLLATE utf8_unicode_ci NOT NULL,
  `pin_code` text COLLATE utf8_unicode_ci NOT NULL,
  `aadhar_card_no` text COLLATE utf8_unicode_ci NOT NULL,
  `poi` text COLLATE utf8_unicode_ci NOT NULL,
  `poa` text COLLATE utf8_unicode_ci NOT NULL,
  `pob` text COLLATE utf8_unicode_ci NOT NULL,
  `por` text COLLATE utf8_unicode_ci NOT NULL,
  `caste_certificate` text COLLATE utf8_unicode_ci NOT NULL,
  `father_income` text COLLATE utf8_unicode_ci NOT NULL,
  `slip` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `sign_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `name_applicant`, `name_father`, `name_mother`, `dob`, `gender`, `age`, `house_no`, `district`, `state`, `pin_code`, `aadhar_card_no`, `poi`, `poa`, `pob`, `por`, `caste_certificate`, `father_income`, `slip`, `photo_applicant`, `sign_applicant`, `date`, `time`) VALUES
(1, 'aadhar_card', '', '', '', '', 'male', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-11', '11:48:43'),
(4, 'income_certificate', 'Mahi', 'Narsappa', 'Pushpa', '2023-07-14', 'female', '21', 'solapur', 'Solapur', 'Maharashtra', '12345', '123445566', 'WhatsApp Image 2022-12-24 at 11.47.34 AM.jpeg', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-13', '09:55:04 AM'),
(5, 'caste_certificate', 'Nandini', '', '', '', 'male', '', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-13', '10:15:11 AM'),
(6, 'caste_certificate', 'Nandini', '', '', '', 'male', '', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-13', '10:15:18 AM'),
(7, 'caste_certificate', 'Deeep', '', '', '', 'male', '', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-13', '10:15:50 AM'),
(9, 'passport', 'bob', 'kevin', 'rose', '2023-07-28', 'male', '34', 'solapur', 'solapur', 'maharashtra', '2100121', '343432', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-15', '19:38:17 PM'),
(10, 'income_certificate', 'purva', 'Narsappa', 'erty', '2023-06-28', 'male', '', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-17', '09:56:46 AM'),
(11, 'caste_validity', '', '', '', '', 'male', '', '', '', '', '', '', '', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-17', '10:12:17 AM'),
(12, 'passport', 'Vinay', '', '', '', 'male', '', '', '', '', '', '', 'WhatsApp Image 2022-12-24 at 11.37.03 AM (1).jpeg', '-', '-', '-', '-', '-', '-', '-', '-', '2023-07-17', '10:13:01 AM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
