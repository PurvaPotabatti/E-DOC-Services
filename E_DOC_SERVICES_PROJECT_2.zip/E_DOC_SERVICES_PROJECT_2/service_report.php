<?php
	require_once('lib/functions.php');
	$db = new class_functions();

	if(isset($_GET['delete_id']))	
	{
		$del_id	= $_GET['delete_id'];
		
		$db->delete_service_record($del_id);
		
	}

?>
<html>
<head>
	<!--Import/Include CSS files-->
	<title>Report</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-utilities.css" />

	<script type="text/javastcript" src="js/bootstrap.js"></script>
	<script type="text/javastcript" src="js/bootstrap.bundle.js"></script>
</head>
<body>

	<h1>Users Report</h1>
	
	<table border="1" cellspacing="0" cellpadding="5">
		<thead>
			<th>Sr No</th>
			<th>Service Name</th>
            <th>Name Applicant</th>
			<th>Name Father</th>
            <th>Name Mother</th>
            <th>DOB</th>
            <th>Age</th>
            <th>House No</th>
            <th>District</th>
            <th>State</th>
            <th>Proof of Identity(poi)</th>
            <th>Proof of Address(poa)</th>
            <th>Proof of Birth(pob)</th>
            <th>Proof of Relationship(por)</th>
            <th>Photo</th>
            <th>Sign</th>
			<th>Date</th>
			<th>Time</th>
			<th>Edit</th>
			<th>Delete</th>
		</thead>
		<tbody>
	<?php
	$users_data = array();
	$users_data = $db->get_data();

	
	if(!empty($users_data))
	{
		$counter = 0;
		
		foreach($users_data as $record)
		{
			    $res_id			    =	$users_data[$counter]['id'];
                $res_service_name   =   $users_data[$counter]['res_service_name'];
			    $res_name_applicant =   $users_data[$counter]['res_name_applicant']; 
				$res_name_father    =   $users_data[$counter]['res_name_father']; 
				$res_name_mother    =   $users_data[$counter]['res_name_mother']; 
				$res_dob            =   $users_data[$counter]['res_dob']; 
				$res_gender         =   $users_data[$counter]['res_gender']; 
				$res_age            =   $users_data[$counter]['res_age']; 
				$res_house_no       =   $users_data[$counter]['res_house_no']; 
				$res_district       =   $users_data[$counter]['res_district']; 
				$res_state          =   $users_data[$counter]['res_state']; 
				$res_poi            =   $users_data[$counter]['res_poi']; 
				$res_poa            =   $users_data[$counter]['res_poa']; 
			    $res_pob            =   $users_data[$counter]['res_pob']; 
			    $res_por            =   $users_data[$counter]['res_por']; 
			    $res_photo_applicant = $users_data[$counter]['res_photo_applicant']; 
				$res_sign_applicant  = $users_data[$counter]['res_sign_applicant']; 
				$res_date            = $users_data[$counter]['res_date'];
				$res_time            = $users_data[$counter]['res_time'];
		?>
			<tr>
				<td><?php echo $counter + 1; ?></td>
				<td><?php echo $res_service_name; ?></td>
                <td><?php echo $res_name_applicant;  ?></td>
				<td><?php echo $res_name_father; ?></td>
				<td><?php echo $res_name_mother;  ?></td>
				<td><?php echo $res_dob;  ?></td>
                <td><?php echo $res_gender;  ?></td>
                <td><?php echo $res_age;  ?></td>
                <td><?php echo $res_house_no;  ?></td>
                <td><?php echo $res_district;  ?></td>
                <td><?php echo $res_state;  ?></td>
                <td><?php echo $res_poi;  ?></td>
                <td><?php echo $res_poa;  ?></td>
                <td><?php echo $res_pob;  ?></td>
                <td><?php echo $res_por;  ?></td>
                 <td><?php echo $res_photo_applicant;  ?></td> 
                <td><?php echo $res_sign_applicant;  ?></td>
                <td><?php echo $res_date;  ?></td>
                <td><?php echo $res_time;  ?></td>
				<td>
					<a href="edit_service.php?edit_id=<?php echo $res_id; ?>">Edit</a>
				</td>
				<td>
					<a href="service_report.php?delete_id=<?php echo $res_id; ?>">Delete</a>
				</td>
			</tr>
		
		<?php
			$counter++;
		}
	}
	else
	{
		echo "No data found";
	}
	?>
			
		</tbody>
	</table>


</body>
</html>