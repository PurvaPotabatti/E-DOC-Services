-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 07, 2023 at 02:53 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_doc_services`
--
CREATE DATABASE IF NOT EXISTS `e_doc_services` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `e_doc_services`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `Password` text COLLATE utf8_unicode_ci NOT NULL,
  `Date` date NOT NULL,
  `Time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=101 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`Id`, `username`, `Password`, `Date`, `Time`) VALUES
(1, 'sayali\r\n', 'sayali', '2023-07-14', '11:43'),
(2, 'Nandini', 'abc123', '2023-07-14', '11:48'),
(3, 'Deepika', '123abc', '2023-07-14', '11:49\r\n'),
(4, 'Purva', '345abc', '2023-07-14', '11:50'),
(5, 'Mayuri', '456abc', '2023-07-14', '11:51');

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE IF NOT EXISTS `apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `mb_no` text COLLATE utf8_unicode_ci NOT NULL,
  `email_id` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=67 ;

--
-- Dumping data for table `apply`
--

INSERT INTO `apply` (`id`, `name`, `mb_no`, `email_id`, `date`, `time`) VALUES
(1, 'Nandini', '7020425399', 'nandinimaheshwaram24@gmail.com', '2023-07-10', '21:54:40'),
(3, 'Rajshri', '8767776735', 'rajshrimaheshwaram16@gmail.com', '2023-07-10', '22:02:47'),
(16, 'Rohit Patil', '8882458892', 'rohit@23gmail.com', '2023-07-12', '16:38:37'),
(23, 'khushi', '9225831363', 'potabattiraman90@gmail.com', '2023-07-19', '18:27:31'),
(28, 'raman', '919225831363', 'potabattiraman90@gmail.com', '2023-07-19', '22:25:57'),
(38, 'deepika', '8010282423', 'deepikasidral@gmail.com', '2023-07-20', '22:40:17'),
(41, 'Vinay', '4353366', 'vinay@gmail.com', '2023-07-21', '13:56:22'),
(51, 'raman', '8010282423', 'potabattiraman90@gmail.com', '2023-07-21', '15:08:44'),
(52, 'Nidhi', '1234567891', 'nidhi@gmail.com', '2023-07-21', '15:11:10'),
(55, 'khushi', '9225831363', 'potabattiraman90@gmail.com', '2023-07-21', '15:24:21'),
(56, 'Vinay', '4353366', 'vinay@gmail.com', '2023-07-21', '16:34:42'),
(57, 'deepika', '08010282423', 'deepikasidral@gmail.com', '2023-07-21', '16:37:27'),
(61, 'khushi', '09225831363', 'potabattiraman90@gmail.com', '2023-07-21', '16:50:09'),
(64, 'deepika', '08010282423', 'deepikasidral@gmail.com', '2023-07-21', '17:01:19'),
(65, 'bob', '9022302137', 'deepikasidral@gmail.com', '2023-07-22', '12:41:25'),
(66, 'raman', '9022302137', 'potabattiraman90@gmail.com', '2023-07-31', '23:29:58');

-- --------------------------------------------------------

--
-- Table structure for table `non_creamy_layer`
--

CREATE TABLE IF NOT EXISTS `non_creamy_layer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `mobile_no` text COLLATE utf8_unicode_ci NOT NULL,
  `father_name` text COLLATE utf8_unicode_ci NOT NULL,
  `mother_name` text COLLATE utf8_unicode_ci NOT NULL,
  `spouse_name` text COLLATE utf8_unicode_ci NOT NULL,
  `district` text COLLATE utf8_unicode_ci NOT NULL,
  `state` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` text COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `occupation` text COLLATE utf8_unicode_ci NOT NULL,
  `proof_of_identity` text COLLATE utf8_unicode_ci NOT NULL,
  `proof_of_address` text COLLATE utf8_unicode_ci NOT NULL,
  `other_doc` text COLLATE utf8_unicode_ci NOT NULL,
  `income_proof` text COLLATE utf8_unicode_ci NOT NULL,
  `caste` text COLLATE utf8_unicode_ci NOT NULL,
  `proof_of_caste` text COLLATE utf8_unicode_ci NOT NULL,
  `profile_photo` text COLLATE utf8_unicode_ci NOT NULL,
  `signature` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` text COLLATE utf8_unicode_ci NOT NULL,
  `name_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `name_father` text COLLATE utf8_unicode_ci NOT NULL,
  `name_mother` text COLLATE utf8_unicode_ci NOT NULL,
  `dob` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` text COLLATE utf8_unicode_ci NOT NULL,
  `age` text COLLATE utf8_unicode_ci NOT NULL,
  `house_no` text COLLATE utf8_unicode_ci NOT NULL,
  `district` text COLLATE utf8_unicode_ci NOT NULL,
  `state` text COLLATE utf8_unicode_ci NOT NULL,
  `poi` text COLLATE utf8_unicode_ci NOT NULL,
  `poi_file` text COLLATE utf8_unicode_ci NOT NULL,
  `poa` text COLLATE utf8_unicode_ci NOT NULL,
  `poa_file` text COLLATE utf8_unicode_ci NOT NULL,
  `pob` text COLLATE utf8_unicode_ci NOT NULL,
  `pob_file` text COLLATE utf8_unicode_ci NOT NULL,
  `por` text COLLATE utf8_unicode_ci NOT NULL,
  `por_file` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `sign_applicant` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=80 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `name_applicant`, `name_father`, `name_mother`, `dob`, `gender`, `age`, `house_no`, `district`, `state`, `poi`, `poi_file`, `poa`, `poa_file`, `pob`, `pob_file`, `por`, `por_file`, `photo_applicant`, `sign_applicant`, `date`, `time`) VALUES
(4, 'income_certificate', 'Mahi', 'Narsappa', 'Pushpa', '2023-07-14', 'female', '21', 'solapur', 'Solapur', 'Maharashtra', 'WhatsApp Image 2022-12-24 at 11.47.34 AM.jpeg', '', '-', '', '-', '', '-', '', '-', '-', '2023-07-13', '09:55:04 AM'),
(46, 'income_certificate', '', '', '', '', 'male', '', '', '', '', 'ration_card', '', 'select_poa', '', 'select_pob', '', 'Select_por', '', '-', '-', '2023-07-18', '11:44:31 AM'),
(49, 'caste_certificate', 'friends', '', '', '', 'male', '', '', '', '', 'pan_card', '', 'passport', '', 'birth_certificate', '', 'marriage_certificate', '', '', '', '2023-07-18', '12:14:00 PM'),
(56, 'aadhar_card', 'Nandini Narsappa Maheshwaram', 'Narsappa Maheshwaram', 'Pushpa Maheshwaram', '2006-04-04', 'female', '17', 'mali nagar,near midc road,solapur', 'Solapur', 'Maharashtra', 'pan_card', 'background1.jpg', 'passport', 'background2.jpg', 'pan_card', 'background3.jpg', 'pension_card', 'background4.jpg', 'background8.jpg', 'background9.jpg', '2023-07-18', '12:45:52 PM'),
(57, 'aadhar_card', 'Nandini Narsappa Maheshwaram', 'Narsappa Maheshwaram', 'Pushpa Maheshwaram', '2006-04-04', 'female', '17', 'mali nagar,near midc road,solapur', 'Solapur', 'Maharashtra', 'pan_card', 'background1.jpg', 'passport', 'background2.jpg', 'pan_card', 'background3.jpg', 'pension_card', 'background4.jpg', 'background8.jpg', 'background9.jpg', '2023-07-18', '12:47:16 PM'),
(60, 'income_certificate', 'Sayali', 'Amar', 'Kshirsagar', '2005-03-31', 'male', '17', 'raghavendra', 'solapur', 'maharashtra', 'driving_licence', 'Screenshot (1).png', 'passport', 'footer2.PNG', 'passport', 'footer4.PNG', 'pension_card', 'footer2.PNG', 'footer2.PNG', 'footer3.PNG', '2023-07-19', '12:25:53 PM'),
(61, 'aadhar_card', 'deepika', 'ambadas', 'kalpana', '2005-04-17', 'female', '18', '1782,datta nagar ', 'solapur', 'maharashtra', 'select_poi', '', 'select_poa', '', 'select_pob', '', 'Select_por', '', '', '', '2023-07-20', '23:07:46 PM'),
(62, 'aadhar_card', 'deepika', 'ambadas', 'kalpana', '2005-04-17', 'female', '18', '1782,datta nagar ', 'solapur', 'maharashtra', 'select_poi', '', 'select_poa', '', 'select_pob', '', 'Select_por', '', '', '', '2023-07-20', '23:29:00 PM'),
(69, 'domicile_certificate', 'purva', 'purva', 'purva', '2023-03-31', 'male', '12', 'raghavendra', 'solapur', 'maharashtra', 'select_poi', 'domicile_certificate.jpeg', 'voter_id', 'driving_license.jpg', 'pan_card', 'Cast-Validity.jpg', 'atm_card', 'debit_card.png', 'aadhar_card.png', 'non_creamy_layer.jpeg', '2023-07-21', '13:49:28 PM'),
(70, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '15:30:56 PM'),
(71, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '16:09:23 PM'),
(72, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '16:10:06 PM'),
(73, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '16:12:16 PM'),
(74, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '16:17:21 PM'),
(75, 'aadhar_card', 'raman', 'raman', 'raman', '2023-07-19', 'male', '9', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'passport', 'domicile_certificate.jpeg', 'passport', 'driving_license.jpg', 'passport', 'electricity_bill.png', 'voter_id.jpeg', 'pan_card2.jpeg', '2023-07-21', '16:29:25 PM'),
(76, 'domicile_certificate', 'kevin', 'kevin', 'kevin', '2023-07-11', 'male', '23', 'raghavendra', 'solapur', 'maharashtra', 'atm_card', 'domicile_certificate.jpeg', 'voter_id', 'domicile_certificate.jpeg', 'birth_certificate', 'electricity_bill.png', 'marriage_certificate', 'driving_license.jpg', 'debit_card.png', 'driving_license.jpg', '2023-07-21', '16:31:23 PM'),
(77, 'domicile_certificate', 'bob', 'raman', 'vaishali', '2023-07-13', 'male', '23', 'raghavendra', 'solapur', 'maharashtra', 'ration_card', 'aadhar_card.png', 'voter_id', 'voter_id.jpeg', 'birth_certificate', 'birth_certificate.jpg', 'passport', 'passport.jpg', 'passport.jpg', 'aadhar_card.png', '2023-07-22', '12:43:36 PM'),
(78, 'passport', 'purva', 'purva', 'purva', '2023-07-26', 'female', '4', 'raghavendra', 'solapur', 'maharashtra', 'select_poi', 'domicile_certificate.jpeg', 'select_poa', 'driving_license.jpg', 'select_pob', 'Cast-Validity.jpg', 'Select_por', 'debit_card.png', 'driving_license.jpg', 'domicile_certificate.jpeg', '2023-07-31', '23:37:03 PM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
