let popup= document.getElementsById("popup");

function openPopup(){
    popup.classlist.add("open-popup");
}

function closePopup(){
    popup.classlist.remove("open-popup");
}