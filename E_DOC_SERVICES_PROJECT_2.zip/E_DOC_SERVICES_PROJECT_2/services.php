<!DOCTYPE html>
<html>

<head>
    <title>Services</title>
    <meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>


    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
    <link rel="stylesheet" type="text/css" href="css/serices_style.css" />
    <link rel="stylesheet" type="text/css" href="css/style_home.css" />
    
    <script type="text/js" src="js/bootstrap.js"></script>
    <script type="text/js" src="js/bootstrap.bundle.js"></script>
	<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
.alert,
.success
{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
.text-design{
    animation: fadeInAnimation ease 3s;
    animation-iterator_count:1;
    animation-fill-mode:forwards;
}
</style>
</head>

<body>
<?php
     require_once('header.php');
?>

    <!--services-->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="section-title text-center mb-4 pb-2">
                    <h1 class="title mb-4 text-design" style="margin:10px">Our Services</h1>
                    <p class="text-muted para-desc mx-auto mb-0" ><h5><br>The E-doc Services provides the following services
                        listed below:</p></h5>
                </div>
            </div><!--end col-->
        </div><!--end row-->

        <div class="row">
            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2" >
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
        
                        <img src="images/aadhar_img.jpeg" alt="Aadhar_Card" width="100px" height="70px">
                    </div>
                    <div class="content mt-4" >
                        <h5 class="title" style="color:white !important">Aadhar Card</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">The Unique Identification Authority of India (UIDAI) issues the Aadhaar card which is 
                            a 12-digit unique identification number assigned to all residents of India. Residents get this number 
                             by providing their biometric and demographic details</p>
                        <div class="mt-3">
                            
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->

            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/stamp.jpg" alt="Income_Certificate" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Income Certificate</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">Income certificate is provided to the citizen by the government confirming and 
                            testifying their annual income.This certification helps to establish economic status of the applicant making him / her eligible 
                            for various government welfare scheme and programs, etc.</p>
                        <div class="mt-3">
                           
                        </div>
                    </div>
                    
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/domicile.jpg" alt="Domicile_Certificate" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title"style="color:white !important">Domicile Certificate</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">A domicile certificate means a permit granted to an individual belonging to an area by 
                            virtue of which he can avail resident quotas in educational institutions, government services, or jobs preferring 
                            locals.A domicile certificate entails several crucial details.</p>
                        <div class="mt-3">
                            
                        </div>
                    </div>
                   
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/passport.jpg" alt="Passport" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Passport</h5>
                        <p class="text-muted mt-3 mb-0 " style="color:white !important">A passport is an official travel document issued by a government that contains a person's identity. A person with a passport can travel to 
                        and from foreign countries more easily and access consular assistance.
                        <div class="mt-3">
                            
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/caste.jpg" alt="Caste_Certificate" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Caste Certificate</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">Caste certificate provides reservation quota in the government jobs as well as job 
                            promotions in the State Government. It mainly helps those who belong to Scheduled Castes (SC) or Scheduled Tribes 
                            (ST). </p>
                        <div class="mt-3">
                            
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/stamp1.jpg" alt="Caste_Validity" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Caste Validity</h5>
                        <p class="text-muted mt-3 mb-0"style="color:white !important">Caste Validity Certificate is one of the very important document For taking benefit of 
                            Scholarship in an educational institution. It mainly helps those who belong to Scheduled Castes (SC) 
                            or Scheduled Tribes (ST).</p>
                        <div class="mt-3">
                           
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->


            <!--new col-->
            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/pan_card3.jpg" alt="Pan_Card" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Pan Card</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">Permanent Account Number or PAN is a mode of identifying taxpayers across the country.
                             PAN is set in the form of a 10-digit unique identification alphanumeric number (containing both alphabets and 
                             numbers) assigned to Indians, mainly to those who pay tax.  </p>
                        <div class="mt-3">
                           
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/voter_id2.jpg" alt="Voter_ID" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Voter ID</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important"> Voter ID card serves as your identity and acts as an official voting ticket.
                             It represents the personal details of an individual, such as the name of the voter, his or her address, 
                             and other fundamental details. A person can apply for the same once he/she has turned 18.</p>
                        <div class="mt-3">
                           
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->


            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                <div class="card service-wrapper rounded border-0 shadow p-4" style="background-color:#000033 !important">
                    <div class="icon text-center text-custom h1 shadow rounded bg-white">
                        <img src="images/non_creamy.jpeg" alt="Non-Creamy_Layer_Certificate" width="100px" height="70px">
                    </div>
                    <div class="content mt-4">
                        <h5 class="title" style="color:white !important">Non-Creamy Layer</h5>
                        <p class="text-muted mt-3 mb-0" style="color:white !important">Non-Creamy Layer Certificate is also known as Other Backward Class Certificate, was 
                            introduced by former Prime Minister V.P.Singh in 1993. With the implementation of this certificate, a part of jobs 
                            was allocated in for persons holding the certificate.</p>
                        <div class="mt-3">
                        
                        </div>
                    </div>
                    
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div>
    <div style="text-align:center;margin-top: 30px;margin-bottom: 30px;">
   <center>
 
   <button type="button" name="apply" class="btn btn-primary btn-lg btn-block" value="Apply" onclick="window.location.href='apply.php';" style="width:30%; height:20%; text-align:center; margin-top:20px;">Apply</button>
</center>

</div>
</body>

</html>