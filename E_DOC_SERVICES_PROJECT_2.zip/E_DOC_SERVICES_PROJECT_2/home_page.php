<html>

<head>
<meta name="keywords" content="software developmnet,website development"/>
<meta name="description" content="Dream Technology mainly focuses on delivering appropriate desktop applications ready for shipping to end users as per software."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>

  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
  <link rel="stylesheet" type="text/css" href="css/style_home.css" />


  <script type="text/js" src="js/bootstrap.js"></script>
  <script type="text/js" src="js/bootstrap.bundle.js"></script>
<style>
body
{
	background-image:url("images/background8.jpg") !important;
    width:100%;
    height:1000px;
	  color:black !important;
}
.block{
  display:flex;
}

.item_footer
{
	display:grid;
	grid-template-columns:repeat(12,1fr);
}

</style>
</head>

<body>
<?php
     require_once('header.php');
?>

  <!doctype html>
  <html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/4.5.6/css/ionicons.min.css">
    <link rel="stylesheet" href="css/style.css">
  </head>

  <body>

    <section class="ftco-section">
      <div class="container ">
        <div class="row">
					
					<div class=" col-md-12">
          <div class="featured-carousel owl-carousel">
            <div class="item">
              <div class="work-wrap d-md-flex">
                <div class="img order-md-last" style="background-image: url(images/client2.jpeg);"></div>
                <div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center"
                  style="background-color:white;">
                  <div class="desc w-100">
                    <h2 class="mb-4">A SATISFIED <br> CUSTOMER IS THE BEST <br>BUSINESS STRATEGY<br>OF ALL</h2>


                  </div>
                </div>
              </div>
            </div>

            <div class="item">
              <div class="work-wrap d-md-flex">
                <div class="img order-md-last" style="background-image: url(images/home_pic.jpg); height:auto"></div>
                <div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center"
                  style="background-color:white;">
                  <div class="py-md-5">
                    <h2 class="mb-4">WE PROVIDE <br> THE BEST SERIVCES</h2>

                    <div class="row justify-content-end">
                      <div class="col-xl-8">
                        <p>To know more about our services check out the below provided link.</p>
                      </div>
                    </div>
                    <p>
                      <a href="services.php"><button type="button" class="btn btn-dark mb-2 py-3 px-4">Learn More</button></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div class="item">
              <div class="work-wrap d-md-flex">
                <div class="img order-md-last" style="background-image: url(images/group1.jpg);"></div>
                <div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center"
                  style="background-color:white;">
                  <div class="py-md-5">
                     <h2 class="mb-4">WELCOME TO <br> E-DOC-SERVICES</h2>
                    <div class="row justify-content-end">
                      <div class="col-xl-8">
                        <p>A safe space and platform to provide users the issued document with guaranteed security.</p>
                        <p>To know more about us, check out the provided link below.</p>
                      </div>
                    </div>
                    <p>
                      <a href="about_us_new.php"><button type="button" class="btn btn-dark mb-2 py-3 px-4">Learn More</button></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div class="item">
              <div class="work-wrap d-md-flex">
                <div class="img order-md-last" style="background-image: url(images/contact-us.jpg);"></div>
                <div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center"
                  style="background-color:white;">
                  <div class="py-md-5">
                    <h2 class="mb-4">YOU ARE <br> FREE TO ASK <br> ANY QUERIES</h2>
                    <div class="row justify-content-end">
                      <div class="col-xl-8">
                        <p>Check out provided below link to contact us.</p>
                      </div>
                    </div>
                    <p>
                      <a href="contact_us_demo.php"><button type="button" class="btn btn-dark mb-2 py-3 px-4">Learn More</button></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
  </body>
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/main.js"></script>



  	<marquee>
	<div style="margin-top:20px;">
	<img src="images/footer1.png" style="margin-right:100px;"/>
	<img src="images/footer2.png" style="margin-right:100px;"/>
	<img src="images/footer3.png" style="margin-right:100px;"/>
	<img src="images/footer4.png" style="margin-right:100px;"/>
	</div>
	</marquee>
   <!-- Footer -->
    <footer class="text-center text-lg-start text-white" style="background-color: #1c2331">
      <!-- Section: Social media -->
      <section class="d-flex justify-content-between p-4" style="background-color: #6351ce">
        <!-- Left -->
        <div class="me-5">
          <span>Get connected with us on social networks:</span>
        </div>
        <!-- Left -->

        <!-- Right -->
        <div>
          <a href="" class="text-white me-4">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-google"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-linkedin"></i>
          </a>
          <a href="" class="text-white me-4">
            <i class="fab fa-github"></i>
          </a>
        </div>
        <!-- Right -->
      </section>
      <!-- Section: Social media -->

      <!-- Section: Links  -->
      <section class="">
        <div class="container text-center text-md-start mt-5">
          <!-- Grid row -->
          <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <!-- Content -->
              <h6 class="text-uppercase fw-bold">Company name</h6>
              <hr class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px" />
              <p>
                E-DOC SERVICES
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold"><a href="services.php">SERVICES</a></h6>
              <hr class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px" />
              <p>
                <a href="#!" class="text-white">Adhar card</a>
              </p>
              <p>
                <a href="#!" class="text-white">Pan card</a>
              </p>
              <p>
                <a href="#!" class="text-white">Passport </a>
              </p>
              <p>
                <a href="#!" class="text-white">Voter id</a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold">Useful links</h6>
              <hr class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px" />
                <p>
                <a href="faq.php" class="text-white"><a href="">FAQs</a></a>
              </p>
              <p>
                <a href="about_us_new.php" class="text-white"><a href="">About us</a></a>
              </p>
              <p>
                <a href="contact_us_demo.php" class="text-white"><a href="">Contact us</a></a>
              </p>
              <p>
                <a href="terms_of_services.php" class="text-white"><a href="">Terms of services</a></a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold">Contact</h6>
              <hr class="mb-4 mt-0 d-inline-block mx-auto"
                style="width: 60px; background-color: #7c4dff; height: 2px" />
              <p><i class="fas fa-home mr-3"></i>Mitra nager,shelgi,solapur.</p>
              <p><i class="fas fa-envelope mr-3"></i>edoc@services.com</p>
              <p><i class="fas fa-phone mr-3"></i>9912-234-1234</p>
            </div>
            <!-- Grid column -->
          </div>
          <!-- Grid row -->
        </div>
      </section>
      <!-- Section: Links  -->

      <!-- Copyright -->
      <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
        © 2023 Copyright:
        <a class="text-white" href="https://mdbootstrap.com/"></a>
      </div>
      <!-- Copyright -->
    </footer>
    <!-- Footer -->


</body>

</html>