<?php
	require_once('table_function.php');
	$db = new class_functions();

	if(isset($_GET['delete_id']))	
	{
		$del_id	= $_GET['delete_id'];
		
		$db->delete_record($del_id);
		
	}

?>
<html>
<head>
	<!--Import/Include CSS files-->
	<title>Report</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-utilities.css" />

	<script type="text/javastcript" src="js/bootstrap.js"></script>
	<script type="text/javastcript" src="js/bootstrap.bundle.js"></script>
	<style>
		
		table th,td{
			border:4px solid;
			
		}
		</style>
</head>
<body>

	<h1>Users Report</h1>
	
	<table border="1" cellspacing="0" cellpadding="5">
		<thead>
			<th>Sr No</th>
			<th>Name</th>
            <th>Mobile No</th>
			<th>Email ID</th>
			<th>Payment</th>
			<th>Date</th>
			<th>Time</th>
			<th>Edit</th>
			<th>Delete</th>
		</thead>
		<tbody>
	<?php
	$users_data = array();
	$users_data = $db->get_all_users_data();

	
	if(!empty($users_data))
	{
		$counter = 0;
		
		foreach($users_data as $record)
		{
			$res_id			=	$users_data[$counter]['id'];
			$res_full_name	=	$users_data[$counter]['name'];
			$res_mb_no   	=	$users_data[$counter]['res_mb_no'];
			$res_email_id	=	$users_data[$counter]['email_id'];
			$res_date		=	$users_data[$counter]['res_date'];
			$res_time		=	$users_data[$counter]['res_time'];
		?>
			<tr>
				<td><?php echo $counter + 1; ?></td>
				<td><?php echo $res_full_name; ?></td>
                <td><?php echo $res_mb_no;  ?></td>
				<td><?php echo $res_email_id; ?></td>
				<td>Done</td>
				<td><?php echo $res_date;  ?></td>
				<td><?php echo $res_time;  ?></td>
				<td>
					<a href="edit.php?edit_id=<?php echo $res_id; ?>">Edit</a>
				</td>
				<td>
					<a href="report.php?delete_id=<?php echo $res_id; ?>">Delete</a>
				</td>
			</tr>
		
		<?php
			$counter++;
		}
	}
	else
	{
		echo "No data found";
	}
	?>
			
		</tbody>
	</table>


</body>
</html>