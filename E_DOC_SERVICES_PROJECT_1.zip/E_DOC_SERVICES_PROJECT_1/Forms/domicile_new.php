<html>
<head>
<title>Domicile</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>

<div class="form_design">
<div class="header">
<img src="images/domicile.jpg" width="100%" height="300px">
<center><h1>Domicile Certifiacte</h1></center>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>



<form action="registration_form.html" method="POST">

<br>
<br>

<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>

<label class="lab">Name of Mother:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>

<label class="lab">Name of Father:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>


<label class="lab">Mobile Number:</label>
<input class="inputbox" type="number" name="mobile number" placeholder="Enter Mobile Number" />
<br>
<br>

<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" />
<br>
<br>

<h3 class="lab">Address:</h3>
<label class="lab">Enter House Address:</label>
<textarea class="inputbox" name="house no" placeholder="Enter Address">
</textarea>
<br>
<br>

<label class="lab">City:</label>
<input class="inputbox" type="text" name="city" placeholder="Enter City" />
<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" />
<br>
<br>

<label class="lab">Enter Aadhar number of Applicant:</label>
<input class="inputbox" type="number" name="aadhar_no_applicant" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">Pin Code:</label>
<input class="inputbox" type="number" name="pin code" placeholder="Enter Pin Code" />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" /><label style="font-size:20px">Male</label>
<input type="radio" name="gender" value="female"/><label style="font-size:20px">Female</label>
<br>
<br>

<h2 style="font-size:30px">Details of:</h2>
<p style="font-size:20px">[Note:Select any one]<p>
<input type="checkbox" name="father" value="father" /><label style="font-size:20px">Father</label>
<input type="checkbox" name="mother" value="mother" /><label style="font-size:20px">Mother</label>
<input type="checkbox" name="guardian" value="guardian" /><label style="font-size:20px">Guardian</label>
<input type="checkbox" name="husband" value="husband" /><label style="font-size:20px">Husband</label>
<input type="checkbox" name="wife" value="wife" /><labelstyle="font-size:20px">Wife</label>
<br>
<br>

<label class="lab"> Enter Name:</label>
<input  class="inputbox" type="text" name="Name" placeholder="Enter Name" />
<br>
<br>
<label class="lab">Aadhar Number:</label>
<input  class="inputbox" type="text" name="aadhar_no" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">LC:</label>
<input class="inputbox" type="file" name="lc" />
 <br>
 <br>
 
 <label class="lab">Bonafide(if applicable):</label>
<input class="inputbox" type="file" name="bonafide" />
 <br>
 <br>

<label class="lab">Proof of Identity</label>
<select class="inputbox" name="poi">
<option value="pan_card">Pan Card</option>
<option value="ration_card">Ration Card</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">
<br>
<br>

<label class="lab">Proof of Address</label>
<select class="inputbox" name="poa">
<option value="passport">Passport</option>
<option value="passbook">Passbook</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="electricity_bill">Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">
<br>
<br>
<label class="lab">Ration Card</label>
<input class="inputbox" type="file" name="ration_card"  />
<br>
<br>


<h2 style="font-size:30px">Details of:</h2>
<p style="font-size:20px">[Note:Select any one]<p>
<input type="checkbox" name="father" value="father" /><label style="font-size:20px">Father</label>
<input type="checkbox" name="mother" value="mother" /><label style="font-size:20px">Mother</label>
<input type="checkbox" name="guardian" value="guardian" /><label style="font-size:20px">Guardian</label>
<input type="checkbox" name="husband" value="husband" /><label style="font-size:20px">Husband</label>
<input type="checkbox" name="wife" value="wife" /><labelstyle="font-size:20px">Wife</label>
<br>
<br>

<label class="lab">Aadhar Card</label>
<input class="inputbox" type="file" name="aadhar_no"  />
<br>
<br>

<label class="lab">Voter ID</label>
<input class="inputbox" type="file" name="voter_id"  />
<br>
<br>

<label class="lab">Photo of Applicant</label>
<input class="inputbox" type="file" name="photo_applicant"  />
<br>
<br>

<label class="lab">Signature of Applicant</label>
<input class="inputbox" type="file" name="sign_applicant"  />
<br>
<br>


<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end">
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right">


</form>
</div>

</body>
</html>