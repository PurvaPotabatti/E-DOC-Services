<?php

	//Include the function file
	require_once('lib/functions.php');
	$db = new class_functions();

	if(isset($_POST['submit_btn']))
	{
		$var_name      = 	  $_POST['name'];
         $var_mb_no     =     $_POST['mb_no'];
		 $var_email_id	=     $_POST['email_id'];
         $var_system_captcha	=	$_POST['system_captcha'];
         $var_user_captcha	=	$_POST['user_captcha'];
         
         if($var_system_captcha==$var_user_captcha)
         {
		if($db->apply($var_name,$var_mb_no,$var_email_id))
       {
			//Send Whatsapp Message
			$whatsapp_message = "
				💥💥💥💥💥💥💥💥 \n

				*DREAM TECHNOLOGY*

				Dear $var_name,
				Thank You For Joining With Us \n

				\n Note:Automatic Software Message".
				"\n💥💥💥💥💥💥💥💥";

				$url =	"http://web.cloudwhatsapp.com/wapp/api/send?apikey=b4e7a2aee0c04eaf8d58357bf6633438&mobile=$var_mb_no&msg=".urlencode($whatsapp_message);
				//	echo $response = file_get_contents($url);
					
						
		
	
		}
    }
    else{
         echo "<div class='alert'>Error in captcha code.Refill the details.</div>";
}
    
	}
?>
<html>
    <head>
    <title>Application</title>
    <meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>

    <link rel="stylesheet" type="text/css" href="css/register_style.css" />
    <style>
	a
	{
		z-index:1000;
	}
    body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
.details
{
	font-size:25px;
}
.alert,
.success
{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
.next{
    float: right;
}
    </style>
    </head>
    <body>
    <?php
       require_once('header.php');
    ?>
    <div id="button" class="next">
        <button type="button" id="enable"name="submit_btn" class="btn btn-primary btn-lg btn-block" value="Submit" onclick="window.location.href='servi.php';" style="width:100px; height:50px; text-align:center;">Next</button>
    
    </div>
    <div class="ctsm_container">
    <div class="form_design">

    <center><h1 style="color:white">Services</h1></center>
    <hr> 
    <div>
        <b><h2 style="color:white">Instructions :</h2></b>
        <p style="font-size:20px">
             1.Enter login detail.Make sure the details entered are of the application itself.
            <br>2.Click Next.
            <br>3.Now,enter further details required for the request of issued document.
            <br>4.Upload the documents images as well.
            <br>5.Make sure the images are in jpg,png,etc.
            <br>6.Later proceed and pay online fee for your selected service using UPI/Phone-pe/Other payment options.
            <br>7.Once done,you will get an acknowledgement receipt through email.
         </p>
		 
    </div>
    
    <form action="apply.php" method="POST">
    
    <br>
    <br>
    
    <label class="details">Name of Applicant:</label>
    <input  class="inputbox" type="text" name="name" placeholder="Enter Name" required/>
    <br>  
    <br>
    
    
    
    <label class="details">Mobile Number:</label>
    <input class="inputbox" type="number" name="mb_no" placeholder="Enter Mobile Number" required/>
    <br>
    <br>
    
    <label class="details">Email Id :</label>
    <input class="inputbox" type="email" name="email_id" placeholder="Enter Email ID" required/>
    <br>
    <br>
    
    <?php
			$random_value = rand(50000,99000)
	  ?>
	  <label class="details">Enter Captcha Code :</label>
	  <input type="text" class="inputbox" readonly  name="system_captcha" value="<?php echo $random_value; ?>" /><br>
	  <input type="text" class="inputbox" name="user_captcha" placeholder="Enter Captcha Code" />
	  
	  <br>
      <br>

    <!--<button type="button" name="submit_btn" class="btn btn-primary btn-lg btn-block" value="Submit" onclick="window.location.href='servi.php';" style="width:100px; height:50px; text-align:center;">Apply</button>-->
    
    
    <center><a href="servi.php"><input type="submit"  name="submit_btn" onclick="enablebtn()" class="btn btn-primary btn-lg btn-block submit_btn" value="Submit" style="width:100px; height:50px; text-align:center;"/><a>
</center>
    <?php
    if(isset($_POST['submit_btn']))
    {
        echo "<div class='success'>User Created Successfully....</div>";
        
    }
    ?>
    </form>
    </div>
    <script>
    function enablebtn(){
        document.getElementById("enable").disable=true;
    }
</script>
  
    </body>
    </html>