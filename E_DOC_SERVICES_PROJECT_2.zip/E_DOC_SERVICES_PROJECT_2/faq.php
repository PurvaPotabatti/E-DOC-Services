<!DOCTYPE html>
<html lang="en">
<head>
<meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta charset="utf-8">


<title>Frequently Asked Questions section - Bootdey.com</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
#box
{
	transition-property:background-color;
	transition-duration:12s;
	transition-timing-function:ease-out;
}
#box:hover
{
	background-color:skyblue;
}
.text-design{
    animation: fadeInAnimation ease 3s;
    animation-iterator_count:1;
    animation-fill-mode:forwards;
}
@keyframes fadeInAnimation{
    0%{
        opacity: 0;
    }
    100%{
        opacity: 1;
    }
}
.design:hover{
    box-shadow:5px 10px 15px #888888;
}
body{margin-top:20px;}
.section_padding_130 {
    padding-top: 130px;
    padding-bottom: 130px;
}
.faq_area {
    position: relative;
    z-index: 1;
	background-image:url("images/background8.jpg") !important;
    height:1000px; 
    width:100%;
   
}

.faq-accordian {
    position: relative;
    z-index: 1;
}
.faq-accordian .card {
    position: relative;
    z-index: 1;
    margin-bottom: 1.5rem;
}
.faq-accordian .card:last-child {
    margin-bottom: 0;
}
.faq-accordian .card .card-header {
    background-color:#000033 ;
    padding: 0;
    border-bottom-color: #ebebeb;
}
.faq-accordian .card .card-header h6 {
    cursor: pointer;
    padding: 1.75rem 2rem;
    color: #3f43fd;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    -ms-grid-row-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
}
.faq-accordian .card .card-header h6 span {
    font-size: 1.5rem;
	
}
.faq-accordian .card .card-header h6.collapsed {
    color: #070a57;
	
}
.faq-accordian .card .card-header h6.collapsed span {
    -webkit-transform: rotate(-180deg);
    transform: rotate(-180deg);
}
.faq-accordian .card .card-body {
    padding: 1.75rem 2rem;
}
.faq-accordian .card .card-body p:last-child {
    margin-bottom: 0;
}

@media only screen and (max-width: 575px) {
    .support-button p {
        font-size: 14px;
    }
}

.support-button i {
    color: #3f43fd;
    font-size: 1.25rem;
}
@media only screen and (max-width: 575px) {
    .support-button i {
        font-size: 1rem;
    }
}

.support-button a {
    text-transform: capitalize;
    color: #2ecc71;
}
@media only screen and (max-width: 575px) {
    .support-button a {
        font-size: 13px;
    }
}

</style>
</head>
<body>
<?php
     require_once('header.php');
?>
<div class="faq_area section_padding_130" id="faq" style="padding:30px"!important;>
<div class="container" >
<div class="row justify-content-center" >
<div class="col-12 col-sm-8 col-lg-6" >

<div class="section_heading text-center wow fadeInUp text-design" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
<h3 style="color:#000033!important; font-size:40px;"><span>Frequently </span> Asked Questions</h3>

<div class="line"></div>
</div>
</div>
</div>
<div class="row justify-content-center">

<div class="col-12 col-sm-10 col-lg-8">
<div class="accordion faq-accordian" id="faqAccordion">

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
<div class="card-header" id="headingOne" >
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" style="color:white !important" >When do I get my issued document?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseOne" aria-labelledby="headingOne" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">We will notify it to you through email. Though it depends on the issued document itself</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
<div class="card-header" id="headingTwo">
<h6 class="mb-0 collapsed  text-design" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" style="color:white !important; border-radius:25px !important;">Can I apply for the other document at same time?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseTwo" aria-labelledby="headingTwo" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">You can apply for a document only at a time. If you want to issue for more documents you must complete the process for first document and then log-in again and issue for the other one.</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
<div class="card-header" id="headingThree">
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree" style="color:white !important">What are the options for online payment?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseThree" aria-labelledby="headingThree" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">You can pay us through Phone-pe, Google-pay, Credit card or UPI qr code.</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
<div class="card-header" id="headingFour">
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour" style="color:white !important">Does you website provides any security?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseFour" aria-labelledby="headingFour" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">Yes we do consider our client's security and privacy.Check out our terms of services to know more.</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
<div class="card-header" id="headingFive">
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive" style="color:white !important">Which services do you usually provide?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseFive" aria-labelledby="headingFive" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">Check out our serives page to know more about it.</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.7s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">
<div class="card-header" id="headingSix">
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix" style="color:white !important">Do we get any receipt from you after the process?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseSix" aria-labelledby="headingSix" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">Yes. We will share you a payment receipt as an acknowledgement to you through email link.</p>
</div>
</div>
</div>

<div class="card border-0 wow fadeInUp design" id="box" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
<div class="card-header text-design" id="headingSeven">
<h6 class="mb-0 collapsed text-design" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven" style="color:white !important">Is signing-in mandatory for you website?<span class="lni-chevron-up"></span></h6>
</div>
<div class="collapse" id="collapseSeven" aria-labelledby="headingSeven" data-parent="#faqAccordion">
<div class="card-body text-design">
<p style="color:#2f2f1e !important">No. But to contact us and to know more about us you ought to sign in.</p>
</div>
</div>
</div>




</div>

<div class="support-button text-center d-flex align-items-center justify-content-center mt-4 wow fadeInUp" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
<i class="lni-emoji-sad"></i>
<p class="mb-0 px-2" style="color:#2f2f1e !important">Can't find your answers?</p>
<a href="#" style="color:#808080 !important"> Contact us</a>
</div>
</div>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
	
</script>
</body>
</html>