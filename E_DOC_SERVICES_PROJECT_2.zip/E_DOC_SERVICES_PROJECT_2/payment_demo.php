
<html>
    <head>
    <title>Application</title>
    <meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>

    <link rel="stylesheet" type="text/css" href="css/register_style.css" />
    <style>
    body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
.details
{
	font-size:25px;
}
.qrcode
{
	width:500px;
	height:500px;
    margin:auto;
}
.alert,
.success

{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
</style>
    </head>
    <body>
    <?php
       require_once('header.php');
    ?>
    <div class="ctsm_container">
    <div class="form_design">

    
    
    <form action="payment_demo.php" method="POST">
    
    <center><h1 style="color:white ">Confirm Your Payment</h1></center>
       <br>
       
    <label class="details">Name of Applicant:</label>
    <input  class="inputbox" type="text" name="name" placeholder="Enter Name" required/>
    <br>  
    <br>
    
    
    <label class="details">Mobile Number:</label>
    <input class="inputbox" type="number" name="mb_no" placeholder="Enter Mobile Number" required/>
    <br>
    <br>
    
    <label class="details">Email Id :</label>
    <input class="inputbox" type="email" name="email" placeholder="Enter Email ID" required/>
    <br>
    <br>
    <label class="details">Select Service Amount: </label>  &nbsp &nbsp &nbsp
       <select style="height:35px; font-size:20px;" name="service">
        <option>Aadhar Card - 125Rs</option>
        <option>Pan Card - 200Rs</option>
        <option>Voter ID- 100Rs</option>
        <option>Income Certificate- 150Rs</option>
        <option> Domicile Certificate- 300Rs</option>
        <option>Cast Certificate - 300Rs</option>
        <option>Cast Validity - 250Rs</option>
        <option>Passport - 700Rs</option>
        <option>Non-Creamy-Layer - 300Rs</option>
</select>
<br>
<br> 
<?php
			$random_value = rand(50000,99000)
	  ?>
	  <label class="details">Enter Captcha Code :</label>
	  <input type="text" class="inputbox" readonly name="system_captcha" value="<?php echo $random_value;?>" /><br>
	  <input type="text" class="inputbox" name="user_captcha" placeholder="Enter Captcha Code" />
	
	      <center><img class="qrcode" src="images/qrcode.jpeg" /></center>
	
    <center><input type="submit" name="send" value="Submit" class="submit_btn" style=" margin-bottom:10px !important;
     padding: 0% !important;" ></center>
    </form>
    </div>
    
    </body>
    </html>
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

  if(isset($_POST['send']))
  {
     $var_system_captcha	=	$_POST['system_captcha'];
         $var_user_captcha	=	$_POST['user_captcha'];
         
         if($var_system_captcha==$var_user_captcha)
         {	  

	        $name = $_POST['name'];
	         $email = $_POST['email'];
	          $service = $_POST['service'];
	



require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'potabattipurva21@gmail.com';                     //SMTP username
    $mail->Password   = 'jnstkdelhjzzftvx';                               //SMTP password
    $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('potabattipurva21@gmail.com', 'E-DOC-SERVICES');
    $mail->addAddress("$email");     //Add a recipient
    
    
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Payment';
    $mail->Body    = "Hey $name, Your payment for $service has been successful!!!";
    

    $mail->send();
    echo "<div class='success'>Payment successful!!!</div>";
    $_SESSION['pay']="Done";
} catch (Exception $e) {
    echo "<div class='alert'>Error in paying. Mailer Error: {$mail->ErrorInfo}</div>";
}
		 }
  
else{
	 echo "<div class='alert'>Error in captha code. Refill the details.</div>";

}
  }
		 
  
?>
