<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
  <link rel="stylesheet" type="text/css" href="css/style_home.css" />


  <script type="text/js" src="js/bootstrap.js"></script>
  <script type="text/js" src="js/bootstrap.bundle.js"></script>
  <style>
  .menu_design:hover
    {
       background-color:white !important;
       color:#000033 !important;
       text-decoration:none !important;
       font-size:12px !important;
       z-index:1000;
    }
    </style>
</head>
<body>
  
  <div class="header">
    <img src="images/logo.jpeg" width="150px" height="80%" style="float:left;">
    <div class="menu">

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-house-fill"
        viewBox="0 0 16 16">
        <path
          d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z" />
        <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z" />
      </svg>
      <a href="home_page.php" class="menu_design" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px; padding:10px;">HOME</a>

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-person-fill"
        viewBox="0 0 16 16">
        <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
      </svg>

     
      <a href="about_us_new.php" class="menu_design" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px; padding:10px;">ABOUT US</a>

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-telephone-fill"
        viewBox="0 0 16 16">
        <path fill-rule="evenodd"
          d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z" />
      </svg>

      
      <a href="contact_us_demo.php"  class="menu_design" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px; padding:10px;">CONTACT US</a>

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-file-earmark-text-fill"
        viewBox="0 0 16 16">
        <path
          d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0zM9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1zM4.5 9a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1h-7zM4 10.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 1 0-1h4a.5.5 0 0 1 0 1h-4z" />
      </svg>
      
      <a href="services.php" class="menu_design" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px;  padding:10px;">SERVICES</a>

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-info-circle-fill"
        viewBox="0 0 16 16">
        <path
          d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" />
      </svg>
      
      <a href="terms_of_services.php" class="menu_design" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px; padding:10px;">TERMS OF SERVICES</a>

      <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="white" class="bi bi-question-circle-fill"
        viewBox="0 0 16 16">
        <path
          d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.496 6.033h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286a.237.237 0 0 0 .241.247zm2.325 6.443c.61 0 1.029-.394 1.029-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94 0 .533.425.927 1.01.927z" />
      </svg>
      
      <a href="faq.php" style="border:1px solid #fff ;border-radius:18px; background-color:#000033; color:white; margin-right:30px; padding:10px;" class="menu_design">FAQ</a>
      

    </div>

  </div>
</body>
</html>