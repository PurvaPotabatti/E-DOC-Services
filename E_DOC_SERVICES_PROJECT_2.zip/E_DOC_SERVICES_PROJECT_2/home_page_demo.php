<html>
<head>
<title>home page</title>
<style>

@import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap');
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
body {
	background-image:url('images/third.jpg');
 background-repeat:no-repeat;
 background-size:100% 100%;
  background-color:  #151719;
   position:relative;
}
.container {
  position: absolute;  
  max-width: 100%;
  z-index:100;
}

.topnav {
  margin-top:150px;  
  float: right !important;
  }

.design
{ display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.waviy {
  position: relative;
  -webkit-box-reflect: below -20rem linear-gradient(transparent, rgba(0,0,0,.2));
  font-size: 90px;
  font-family: 'Alfa Slab One', cursive;
}
.waviy span {
  font-family: 'Alfa Slab One', cursive !important;
  position: relative;
  display: inline-block;
  color: #fff;
  text-transform: uppercase;
  animation: waviy 1s infinite;
  animation-delay: calc(.1s * var(--i));
  
}
@keyframes waviy {
  0%,40%,100% {
    transform: translateY(0)
  }
  20% {
    transform: translateY(-20rem)
  }
}
 a{
   text-decoration:none;
 }
</style>
</head>
<body>
<div class="waviy design">
<a href="home_page.php"> <span style="--i:1">E</span>
   <span style="--i:2">&nbsp</span>
   <span style="--i:3">&nbsp</span>
   <span style="--i:4">D</span>
   <span style="--i:5">O</span>
   <span style="--i:6">C</span>
   <span style="--i:7">&nbsp</span>
   <span style="--i:8">&nbsp</span>
   <span style="--i:9">S</span>
   <span style="--i:10">E</span>
    <span style="--i:7">R</span>
   <span style="--i:8">V</span>
    <span style="--i:7">I</span>
   <span style="--i:8">C</span>
    <span style="--i:7">E</span>
   <span style="--i:8">S</span></a>
   
</div>
</body>
</html>