 <html>
<head>
<title>Aadhar card</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>

</style>
</head>
<body style="background-image:url("images\background3.jpg");">
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/aadhar_img.jpeg" width="100%" height="210px">
</div>

<center><h1>Aadhar Card</h1></center>

<form action="aadhar_card_registration.html" method="POST">
<br>
<br>

<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
<br>
<br>


<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" />Male
<input type="radio" name="gender" value="female"/>Female
<br>
<br>

<label class="lab">Age:</label>
<input class="inputbox" type="number" name="age" placeholder="Enter Age" />
<br>
<br>

<h2>Address:</h2>
<label class="lab">Enter House Address:</label>
<textarea class="inputbox" name="house_no" placeholder="Enter Address">
</textarea>
<br>
<br>

<label class="lab">City:</label>
<input class="inputbox" type="text" name="city" placeholder="Enter City" />
<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" />
<br>
<br>

<label class="lab">Pin Code:</label>
<input class="inputbox" type="number" name="pin_code" placeholder="Enter Pin Code" />
<br>
<br>

<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi">
<option value="select_poi">Select Proof of Identity</option>
<option value="pan_card">Pan Card</option>
<option value="ration_card">Ration Card</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">
<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa">
<option value="select_poa">Select Proof of Address</option>
<option value="passport">Passport</option>
<option value="passbook">Passbook</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="electricity_bill">Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">
<br>
<br>

<label class="lab">Proof of Birth:</label>
<select class="inputbox" name="pob">
<option value="select_pob">Select Proof of Birth</option>
<option value="pan_card">Pan Card</option>
<option value="birth_certificate">Birth Certificate</option>
<option value="passport">Passport</option>
<option value="slc">School Leaving Certificate </option>
</select>
<input class="inputbox" type="file" name="pob_file">
<br>
<br>

<label class="lab">Proof of Relationship:</label>
<select class="inputbox" name="por">
<option value="Select_por">Select Proof of Relationship</option>
<option value="pds_card">PDS Card</option>
<option value="pension_card">Pansion Card</option>
<option value="passport">Passport</option>
<option value="marriage_certificate">Marriage Certificate</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="por_file">
<br>
<br>

<h2>Details of:</h2>
<p>[Note:Select any one]<p>
<input type="checkbox" name="father" value="father" />Father
<input type="checkbox" name="mother" value="mother" />Mother
<input type="checkbox" name="guardian" value="guardian" />Guardian
<input type="checkbox" name="husband" value="husband" />Husband
<input type="checkbox" name="wife" value="wife" />Wife
<br>
<br>

<label class="lab"> Enter Name:</label>
<input  class="inputbox" type="text" name="Name" placeholder="Enter Name" />
<br>
<br>

<label class="lab">Aadhar Number:</label>
<input  class="inputbox" type="text" name="aadhar_no" placeholder="Enter Aadhar Number" />
<br>
<br>

<label class="lab">Photo of Applicant:</label>
<input class="inputbox" type="file" name="photo_applicant"  />
<br>
<br>

<label class="lab">Signature of Applicant:</label>
<input class="inputbox" type="file" name="sign_applicant"  />
<br>
<br>


<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end"/>
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right"/>


</form>
</div>

</body>
</html>