<?php
	//Include function file
	require_once('lib/functions.php');
	$db = new class_functions();
	
	if(isset($_GET['logout']))
	{
		unset($_SESSION['login_username']);
	}
	
	
	if(isset($_POST['login']))
	{
		$var_username = $_POST['username'];
		$var_password	=	$_POST['password'];
		
		$db_password	=	$db->get_user_password($var_username);
		
		if($db_password=="")
		{
			echo "This user is not registered with us. Check Username";
		}
		else
		{
			if($var_password==$db_password)
			{
			    echo "login Success";
				$_SESSION['login_username']	=	$var_username;
				require_once('.php');
				
			}
			else{
				echo "Incorrect password";
			}
		}
		
	}
?>	
<!doctype html>
<html>
  <head>
  	<title>User_login</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-utilities.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.rtl.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-utilities,rtl.css" />
	<link rel="stylesheet" type="text/css" href="style.css" />

	
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>

<style>
body {
     background-image:url("images/background8.jpg") !important;
}

.height-100 {
    height: 500px
}

.sidebar {
    position: relative;
    overflow: hidden
}

.chart-design {
    list-style: none
}

.chart-design li:nth-child(1) {
    position: absolute;
    top: 10px;
    height: 100px;
    width: 100px;
    background-color: #1818a3;
    border-radius: 100% 0% 0% 100% / 0% 56% 44% 100%;
    opacity: 0.4
}

.chart-design li:nth-child(2) {
    position: absolute;
    top: 30px;
    right: 20px;
    transform: rotate(-10deg);
    height: 70px;
    width: 70px;
    background-color: #121242;
    border-radius: 100% 0% 0% 100% / 0% 56% 44% 100%;
    opacity: 0.4
}

.chart-design li:nth-child(3) {
    position: absolute;
    bottom: 0px;
    left: 200px;
    transform: rotate(-10deg);
    height: 150px;
    width: 150px;
    background-color: #0707a3;
    border-radius: 100% 0% 0% 100% / 0% 56% 44% 100%;
    opacity: 0.4
}

.chart-design li:nth-child(4) {
    position: absolute;
    bottom: 0px;
    left: 10px;
    transform: rotate(-10deg);
    height: 150px;
    width: 150px;
    background-color: #19197a;
    border-radius: 50%;
    opacity: 0.4
}

.chart-design li:nth-child(5) {
    position: absolute;
    bottom: 0px;
    right: 10px;
    transform: rotate(-10deg);
    height: 70px;
    width: 70px;
    background-color: #1313a0;
    border-radius: 50%;
    opacity: 0.7
}

.chart-design li:nth-child(6) {
    position: absolute;
    top: 120px;
    left: 40%;
    transform: rotate(-10deg);
    height: 200px;
    width: 200px;
    background-color: #21218f;
    border-radius: 50%;
    opacity: 0.2
}

.form-data {
    width: 100%;
    margin-bottom: 10px
}

.main-heading {
    font-size: 30px
}

.form-data label {
    font-size: 13px;
    margin-left: 2px
}

.form-data input {
    height: 50px;
    border: 2px solid #eee;
    transition: all 1s;
    border-radius: 5px
}

.form-data input:focus {
    outline: none;
    border: 2px solid #000033;
    box-shadow: none
}

.social-list {
    list-style: none;
    display: flex
}

.social-list li {
    margin: 5px;
    background-color: #b7c2d4;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    transition: all 0.5s;
    cursor: pointer;
    color: #fff
}

.forgot-text {
    color: red
}

.social-list li:nth-child(1) {
    background-color: #1828fe
}

.social-list li:nth-child(2) {
    background-color: red
}

.social-list li:nth-child(3) {
    background-color: #1828fe
}

.signin-btn .btn {
    width: 100%;
    height: 46px;
    margin-top: 10px
}
.btn-block
{
background-color:#000033 !important;
border:2px solid #0e0e58 !important ;
}
.btn-block:hover {
  background-color: white !important; 
  color: #404040 !important;
}
a:hover
{
color:#404040 !important;
}
.alert,
.success
{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
 
</style>
	</head>
	<body>
	<div class="container">
    <div class="row g-0 mt-5 mb-5 height-100">
        <div class="col-md-6">
            <div class=" p-4 h-100 sidebar" style="background-color: #000033;">
                <ul class="chart-design">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
        </div>
        <div class="col-md-6">
            <div class="bg-white p-4 h-100">
			<form action="PurpleAdmin\PurpleAdmin\index.php" method="POST">
                <div class="p-3 d-flex justify-content-center flex-column align-items-center"> <span class="main-heading" style="font-size:35px; font-family:Cambria;">ADMIN PANNEL</span>
                    
					<ul class="social-list mt-3">
                         </ul>
						 
                    <div class="form-data"> <label style="font-size:25px; font-family:Cambria;">Username</label> <input type="text" class="form-control w-100" name="username" /> </div>
                    <div class="form-data"> <label style="font-size:25px; font-family:Cambria;">Password</label> <input type="text" class="form-control w-100" name="password"> </div>
                    <div class="d-flex justify-content-between w-100 align-items-center">
                        
                    
					<div class="signin-btn w-100 mt-2"><center><input type="submit" name="login" value="login" width="30px" height="15px"/></center> </div>
					</form>
                    <?php
    if(isset($_POST['login']))
    {
        echo "<div class='success'>Admin Login Successful....</div>";
    }
    ?>
                </div>
            </div>
        </div>
    </div>
</div>
	</body>
</html>

