<html>
    <head>
    <title>Domicile_Application</title>
    <link rel="stylesheet" type="text/css" href="css/register_style.css" />
    <style>
     body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
.details
{
	font-size:25px;
}
    </style>
    </head>
    <body >
    <div class="ctsm_container">
    <div class="form_design">

    <center><h1>Domicile Certificate</h1></center>
     <hr>
    <div>
        <b><h2>Instructions :</h2></b>
        <p style="font-size:20px">
             1.Enter login detail.Make sure the details entered are of the application itself.
            <br>2.Click Next.
            <br>3.Now,enter further details required for the request of issued document.
            <br>4.Upload the documents images as well.
            <br>5.Make sure the images are in jpg,png,etc.
            <br>6.Later proceed and pay online fee for your selected service using UPI/Phone-pe/Other payment options.
            <br>7.Once done,you will get an acknowledgement receipt through email.
         </p>
    </div>
    
    <form action="domicile_apply.php" method="POST">
    
    <br>
    <br>
    
    <label class="details">Name of Applicant:</label>
    <input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" />
    <br>
    
    <br>
    
    
    <label class="details">Mobile Number:</label>
    <input class="inputbox" type="number" name="mb_no" placeholder="Enter Mobile Number" />
    <br>
   <br>
    
    <label class="details">Email Id :</label>
    <input class="inputbox" type="email" name="age" placeholder="Enter Email ID" />
    <br>
    <br>
    

    <input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end">
    <input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right">
    
    
    </form>
    </div>
    
    </body>
    </html>