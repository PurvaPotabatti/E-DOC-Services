<!DOCTYPE html>
<html lang="en">
  <head>
  <meta name="keywords" content="E doc services,E services,E seva,government services, E seva kendra"/>
<meta name="description" content="."/>
<meta name="robots" content="index">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Form</title>
    <link rel="stylesheet" href="css/style_contact.css"/>
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"></script>
	  <style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
.alert,
.success
{
	width:400px;
	text-align:center;
	position:absolute;
	top:30px;
	left:50%;
	transform:translateX(-50%);
	color:whitesmoke;
	padding:8px 0;
}
.alert{background-color:rgb(252,59,59);}
.success{background-color:rgb(44,158,24);}
</style>
  </head>
  <body >
  <?php
     require_once('header.php');
?>
  <div class="cstm_container" style="background-image:url('images\background.jpg')" !important >
    <div class="container">
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title1">Let's get in touch</h3>
          <p class="text">
           Our team is happy to read your questions.Contact us with following ways,and we'll be in touch as soon as possible. 
          </p>

          <div class="info">
            <div class="information">
              <img src="img/location.png" class="icon" alt="" />
              <p>Mitra nager,shelgi,solapur.</p>
            </div>
            <div class="information">
              <img src="img/email.png" class="icon" alt="" />
              <p>edoc@services.com</p>
            </div>
            <div class="information">
              <img src="img/phone.png" class="icon" alt="" />
              <p>9912-234-1234</p>
            </div>
          </div>

          <div class="social-media">
            <p>Connect with us :</p>
            <div class="social-icons">
              <a href="#">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="#">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="contact_us_demo.php" autocomplete="off" method="POST">
            <h3 class="title">Contact us</h3>
            <div class="input-container">
              <input type="text" name="name" class="input" placeholder="Username" />
              
            </div>
            <div class="input-container">
              <input type="email" name="email" class="input" placeholder="Email ID"/>
          
            </div>
            
            <div class="input-container textarea">
              <textarea name="msg" class="input" placeholder="Message"></textarea>
            </div>
            <button  style="background-color:#000033 !important" type="submit" class="btn btn-primary btn-sm" name="send">Send</button>
          </form>
        </div>
      </div>
    </div>

    <script src="app.js"></script>
	</div>
  </body>
</html>
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if(isset($_POST['send']))
{
	$name = $_POST['name'];
	$email = $_POST['email'];
	$msg = $_POST['msg'];
	

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'potabattipurva21@gmail.com';                     //SMTP username
    $mail->Password   = 'jnstkdelhjzzftvx';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom("$email");
    $mail->addAddress('potabattipurva21@gmail.com', 'Our website');     //Add a recipient
    
    
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'User details:';
    $mail->Body    = "User name-$name <br> User email-$email <br> Message - $msg<br>";
    

    $mail->send();
    echo "<div class='success'>Message has been sent</div>";
} catch (Exception $e) {
    echo "<div class='alert'>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</div>";
}
}
?>