<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Form</title>
    <link rel="stylesheet" href="css/style_payment.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
body
{
	margin-top:100px;
    background-image:url("images/back.jpg");
    width:100%;
    height:1000px;
}
</style>
</head>
<body>
<?php
   require_once('header.php');
?>

    <div class="container">
        <h1>Confirm Your Payment</h1>
        
            <div class="owner">
                <h3>Name</h3>
                <div class="input-field">
                    <input type="text">
                </div>
				<br/>
				<h3>Email ID</h3>
                <div class="input-field">
                    <input type="email">
                </div>
            </div>
			<br/>
            <div class="mobi">
                <h3>Mobile no.</h3>
                <div class="input-field">
                    <input type="text">
                </div>
            </div>
			
			 <br/>
				<h3>Scan QR code :</h3>
			 <img class="qrcode" src="images/Qr_code.jpeg"/>
	
	        <a href="">Confirm</a>
        
    </div>
	
</body>
</html>
