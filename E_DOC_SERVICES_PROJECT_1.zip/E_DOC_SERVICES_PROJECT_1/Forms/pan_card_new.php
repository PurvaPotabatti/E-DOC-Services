<html>
<head>
<title>Pan Card</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/pan_card3.jpg" width="100%" height="300px">
	<center><h1>Pan Card</h1></center>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<form action="registration_form.html" method="POST">

<br>
<br>

<label class="lab">Name of Applicant:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name" required />
<br>
<br>


<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" required />
<br>
<br>


<label class="lab">Mobile number</label>
<input class="inputbox" type="number" name="age" placeholder="Enter Mobile number" required />
<br>
<br>

<label class="lab">Father's name</label>
<input  class="inputbox" type="text" name="Father_name" placeholder="Enter Father Name" required />
<br>
<br>

<label class="lab">Mother's name</label>
<input  class="inputbox" type="text" name="Mother_name" placeholder="Enter Mother Name" required />
<br>
<br>

<label class="lab">Spouse's name</label>
<input  class="inputbox" type="text" name="Spouse_name" placeholder="Enter Spouse Name" />
<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" required />
<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" required />
<br>
<br>

<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" /><label style="font-size:20px">Male</label>
<input type="radio" name="gender" value="female"/><label style="font-size:20px">Female</label>
<br>
<br>

 
<label class="lab">Address</label>
<textarea class="inputbox" name="address" placeholder="Enter your Address" required>
</textarea>

<label class="lab">Occupation:</label>
<input class="inputbox" type="text" name="occupation" placeholder="Enter your Occupation" required />
<br>
<br>


<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi" required >
<option value="select_poi">Select Proof of Identity</option>
<option value="pan_card">Ration card with the applicant's photograph</option>
<option value="ration_card">Passport</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank certificate containing an attested photograph of the applicant along with bank account number of the applicant</option>
<option value="atm_card">Arm's license</option>
<option value="atm_card">Aadhar card</option>
</select>
<input class="inputbox" type="file" name="poi_file" required >
<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa" required>
<option value="select_poa">Select Proof of Address</option>
<option value="passport">Passport</option>
<option value="passbook">Passport:self</option>
<option value="passbook1">Passport:spaouse</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Domicile certificate issued by government</option>
<option value="electricity_bill">Electricity Bill</option>
<option value="electricity_bill">Ration Card</option>
<option value="electricity_bill">Aadhar Card</option>
<option value="electricity_bill">Telephone Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file" required />
<br>
<br>

<label class="lab">DOB proof documents</label>
<select class="inputbox" name="other_doc" required>
<option value="select_pob">Select DOB proof document</option>
<option value="birth_certificate">Birth certificate issued by the Municipal Authority or any office authorized Registrar</option>
<option value="pension_certificate">Pension payment order</option>
</select>
<input class="inputbox" type="file" name="other_doc_file" required>
<br>
<br>


<b><label class="lab">Mandatory Documents:</label></b>
<br>

<label class="lab">Income proof</label>
<input class="inputbox" type="file" name="income" required>
<br>
<br>

<label class="lab">Affidavit for caste</label>
<input class="inputbox" type="file" name="caste" required>
<br>
<br>

<label class="lab">Proof of caste for self</label>
<input class="inputbox" type="file" name="caste_proof" required>
<br>
<br>


<b><label class="lab">Photo of Applicant:</label></b>
<input class="inputbox" type="file" name="photo_applicant"  />
<br>
<br>

<b><label class="lab">Signature of Applicant:</label></b>
<input class="inputbox" type="file" name="sign_applicant"  />
<br>
<br>


<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end">
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right">


</form>
</div>

</body>
</html>