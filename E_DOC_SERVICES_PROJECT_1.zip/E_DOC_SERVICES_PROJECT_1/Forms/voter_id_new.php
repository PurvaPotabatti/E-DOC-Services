<html>
<head>
<title>Voter id</title>
<link rel="stylesheet" type="text/css" href="css/register_style.css" />
<style>
body
{
    background-image:url("images/background8.jpg");
    width:100%;
    height:1000px;
    
}
</style>
</head>
<body>
<div class="ctsm_container">
<div class="form_design">
<div class="header">
    <img src="images/voter_id2.jpg" width="100%" height="300px">
	<center><h1>Voter ID</h1></center>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<form action="registration_form.html" method="POST">

<br>
<br>

<label class="lab">Enter Aadhar Number:</label>
<input  class="inputbox" type="text" name="Aadhar_number" placeholder="Enter Aadhar Number" />

<br>
<br> 

<label class="lab">Name of Beneficiar:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name of Beneficiar" />

<br>
<br>

<label class="lab">Name of Father:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name of Father" />

<br>
<br>

<label class="lab">Name of Mother:</label>
<input  class="inputbox" type="text" name="Name_applicant" placeholder="Enter Name of Mother" />

<br>
<br>


<label class="lab">Select gender:</label>
<input type="radio" name="gender" checked value="male" />Male
<input type="radio" name="gender" value="female"/>Female


<br>
<br>

<label class="lab">DOB:</label>
<input class="inputbox" type="date" name="dob" placeholder="Enter Dob" />

<br>
<br>

<h3 style="font-size:30">Address:</h3>
<label class="lab">Enter House no/apt:</label>
<textarea class="inputbox" name="house_no" placeholder="Enter Address">
</textarea>

<br>
<br>


<label class="lab">City:</label>
<input class="inputbox" type="text" name="city" placeholder="Enter City" />

<br>
<br>

<label class="lab">District:</label>
<input class="inputbox" type="text" name="district" placeholder="Enter District" />

<br>
<br>

<label class="lab">State:</label>
<input class="inputbox" type="text" name="state" placeholder="Enter State" />

<br>
<br>

<label class="lab">Pin Code:</label>
<input class="inputbox" type="number" name="pin_code" placeholder="Enter Pin Code" />


<br>
<br>

<label class="lab">Proof of Identity:</label>
<select class="inputbox" name="poi">
<option value="select_poi">Select Proof of Identity </option>
<option value="pan_card">Pan Card</option>
<option value="ration_card">Ration Card</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="atm_card">Bank ATM Card</option>
</select>
<input class="inputbox" type="file" name="poi_file">

<br>
<br>

<label class="lab">Proof of Address:</label>
<select class="inputbox" name="poa">
<option value="select_poa">Select Proof of Address</option>
<option value="passport">Passport</option>
<option value="passbook">Passbook</option>
<option value="voter_id">Voter ID</option>
<option value="driving_licence">Driving Licence</option>
<option value="electricity_bill">Electricity Bill</option>
</select>
<input class="inputbox" type="file" name="poa_file">

<br>
<br>

<label class="lab">Proof of Age:</label>
<select class="inputbox" name="proof_of_age">
<option value="select_proof_of_age">Select Proof of Age</option> 
<option value="pan_card">Pan Card</option>
<option value="birth_certificate">Birth Certificate</option>
<option value="aadhar_card">Aadhar Card</option>
<option value="driving_licence">Driving Licence </option>
</select>
<input class="inputbox" type="file" name="pob_file">

<br>
<br>

<label class="lab">Photo of Applicant</label>
<input class="inputbox" type="file" name="photo_applicant"/>

<br>
<br>

<label class="lab">Signature of Applicant: </label>
<input class="inputbox" type="file" name="sign_applicant"  />


<br>
<br>


<input type="submit" name="close" value="Back" class="submit_btn" style="float:inline-end">
<input type="submit" name="submit" value="Submit" class="submit_btn" style="float:right">


</form>
</div>

</body>
</html>